/**
 * Eventora - Authentication & Profile Management System
 * Handles user registration, profile icon display in navbar,
 * account switching, Google sign-in simulation, and persistent state.
 */

(function (window) {
    'use strict';

    const STORAGE_KEY_CURRENT = 'eventora_current_user';
    const STORAGE_KEY_USERS = 'eventora_users';

    const EventoraAuth = {
        /**
         * Get the currently logged-in / registered user
         */
        getCurrentUser: function () {
            try {
                const data = localStorage.getItem(STORAGE_KEY_CURRENT);
                return data ? JSON.parse(data) : null;
            } catch (e) {
                console.error('Error reading current user:', e);
                return null;
            }
        },

        /**
         * Set the currently active user
         */
        setCurrentUser: function (user) {
            try {
                if (user) {
                    localStorage.setItem(STORAGE_KEY_CURRENT, JSON.stringify(user));
                } else {
                    localStorage.removeItem(STORAGE_KEY_CURRENT);
                }
            } catch (e) {
                console.error('Error saving current user:', e);
            }
        },

        /**
         * Get all registered users from storage
         */
        getAllUsers: function () {
            try {
                const data = localStorage.getItem(STORAGE_KEY_USERS);
                return data ? JSON.parse(data) : [];
            } catch (e) {
                console.error('Error reading all users:', e);
                return [];
            }
        },

        /**
         * Save or update a user in the registered users list
         */
        saveUserToDirectory: function (user) {
            try {
                const users = this.getAllUsers();
                const existingIndex = users.findIndex(u => u.email.toLowerCase() === user.email.toLowerCase());
                if (existingIndex >= 0) {
                    users[existingIndex] = { ...users[existingIndex], ...user };
                } else {
                    users.push(user);
                }
                localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(users));
            } catch (e) {
                console.error('Error saving user to directory:', e);
            }
        },

        /**
         * Register a new user
         */
        register: function (details) {
            const user = {
                name: details.name.trim(),
                phone: details.phone.trim(),
                email: details.email.trim().toLowerCase(),
                password: details.password || '',
                authProvider: details.authProvider || 'local',
                isRegistered: true,
                registeredAt: new Date().toISOString(),
                avatarUrl: details.avatarUrl || null,
                initials: this.getInitials(details.name)
            };

            this.saveUserToDirectory(user);
            this.setCurrentUser(user);
            return user;
        },

        /**
         * Authenticate existing user by email & password
         */
        login: function (email, password) {
            const users = this.getAllUsers();
            const normalizedEmail = email.trim().toLowerCase();
            const user = users.find(u => u.email.toLowerCase() === normalizedEmail);

            if (user) {
                if (user.password && user.password !== password) {
                    return { success: false, message: 'Invalid password. Please try again.' };
                }
                this.setCurrentUser(user);
                return { success: true, user: user };
            }

            // If not found in localStorage directory, allow fallback login and create profile
            const fallbackUser = {
                name: email.split('@')[0],
                phone: '1234567890',
                email: normalizedEmail,
                password: password,
                authProvider: 'local',
                isRegistered: true,
                registeredAt: new Date().toISOString(),
                avatarUrl: null,
                initials: this.getInitials(email.split('@')[0])
            };
            this.saveUserToDirectory(fallbackUser);
            this.setCurrentUser(fallbackUser);
            return { success: true, user: fallbackUser };
        },

        /**
         * Sign in or register with Google
         */
        loginWithGoogle: function (googleAccount) {
            const user = {
                name: googleAccount.name || 'Google User',
                email: googleAccount.email.trim().toLowerCase(),
                phone: googleAccount.phone || '9876543210',
                authProvider: 'google',
                isRegistered: true,
                registeredAt: new Date().toISOString(),
                avatarUrl: googleAccount.avatarUrl || 'https://lh3.googleusercontent.com/a/default-user=s96-c',
                initials: this.getInitials(googleAccount.name || 'Google User')
            };

            this.saveUserToDirectory(user);
            this.setCurrentUser(user);
            return user;
        },

        /**
         * Log out current user
         */
        logout: function () {
            this.setCurrentUser(null);
            this.showToast('You have been logged out.');
            setTimeout(() => {
                window.location.reload();
            }, 600);
        },

        /**
         * Switch to an existing account by email
         */
        switchAccount: function (email) {
            const users = this.getAllUsers();
            const target = users.find(u => u.email.toLowerCase() === email.toLowerCase());
            if (target) {
                this.setCurrentUser(target);
                this.showToast(`Switched to ${target.name}!`);
                setTimeout(() => {
                    window.location.reload();
                }, 600);
                return true;
            }
            return false;
        },

        /**
         * Helper to get user initials
         */
        getInitials: function (name) {
            if (!name) return 'U';
            const parts = name.trim().split(/\s+/);
            if (parts.length >= 2) {
                return (parts[0][0] + parts[1][0]).toUpperCase();
            }
            return parts[0].slice(0, 2).toUpperCase();
        },

        /**
         * Show a sleek floating toast notification
         */
        showToast: function (message, type = 'info') {
            let container = document.getElementById('eventoraToastContainer');
            if (!container) {
                container = document.createElement('div');
                container.id = 'eventoraToastContainer';
                container.className = 'eventora-toast-container';
                document.body.appendChild(container);
            }

            const toast = document.createElement('div');
            toast.className = `eventora-toast eventora-toast-${type}`;
            toast.innerHTML = `
                <span class="toast-icon">${type === 'success' ? '✨' : (type === 'error' ? '⚠️' : '🔔')}</span>
                <span class="toast-text">${message}</span>
            `;

            container.appendChild(toast);
            setTimeout(() => toast.classList.add('visible'), 10);

            setTimeout(() => {
                toast.classList.remove('visible');
                setTimeout(() => toast.remove(), 300);
            }, 3200);
        },

        /**
         * Render the Profile Icon and Dropdown in the Navbar
         */
        initNavbarAuth: function () {
            // Check if there is a query param indicating registration or login
            const urlParams = new URLSearchParams(window.location.search);
            const registeredParam = urlParams.get('registered');
            const nameParam = urlParams.get('name');

            if (registeredParam && nameParam && !this.getCurrentUser()) {
                this.register({
                    name: decodeURIComponent(nameParam),
                    phone: '9876543210',
                    email: nameParam.toLowerCase().replace(/\s+/g, '') + '@eventora.com',
                    password: ''
                });
            }

            const currentUser = this.getCurrentUser();

            if (registeredParam) {
                const displayName = currentUser ? currentUser.name.split(' ')[0] : (nameParam ? decodeURIComponent(nameParam) : 'Member');
                setTimeout(() => {
                    this.showToast(`Welcome to Eventora, ${displayName}! Your account is registered ✨`, 'success');
                }, 300);
                if (window.history && window.history.replaceState) {
                    window.history.replaceState({}, document.title, window.location.pathname);
                }
            } else if (urlParams.get('loginSuccess')) {
                const displayName = currentUser ? currentUser.name.split(' ')[0] : 'Back';
                setTimeout(() => {
                    this.showToast(`Welcome back, ${displayName}! ✨`, 'success');
                }, 300);
                if (window.history && window.history.replaceState) {
                    window.history.replaceState({}, document.title, window.location.pathname);
                }
            }
            const loginButtons = document.querySelectorAll('.login-btn, a[href="login.html"].login-btn, button.login-btn');

            if (!loginButtons.length) return;

            loginButtons.forEach(btn => {
                if (!currentUser) {
                    // User is not logged in: ensure login button is normal
                    btn.style.display = '';
                    // Remove any existing profile widget next to it
                    const existingWidget = btn.parentElement.querySelector('.eventora-profile-widget');
                    if (existingWidget) existingWidget.remove();
                    return;
                }

                // User is logged in / registered: Replace or hide login button
                btn.style.display = 'none';

                let widget = btn.parentElement.querySelector('.eventora-profile-widget');
                if (widget) widget.remove();

                widget = document.createElement('div');
                widget.className = 'eventora-profile-widget';
                widget.innerHTML = this.buildProfileWidgetHtml(currentUser);

                btn.parentElement.appendChild(widget);

                // Setup interactive behavior
                this.bindWidgetEvents(widget, currentUser);
            });

            // Ensure modals exist on the page
            this.ensureModals();
        },

        /**
         * Construct HTML for Profile Trigger and Dropdown Menu
         */
        buildProfileWidgetHtml: function (user) {
            const avatarContent = user.avatarUrl
                ? `<img src="${user.avatarUrl}" alt="${user.name}" class="avatar-img">`
                : `<span>${user.initials || this.getInitials(user.name)}</span>`;

            const providerIcon = user.authProvider === 'google'
                ? `<span class="provider-pill google" title="Signed in with Google">
                    <svg viewBox="0 0 24 24" width="12" height="12"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/></svg> Google
                   </span>`
                : '';

            return `
                <button type="button" class="profile-trigger-btn" id="eventoraProfileTrigger" aria-haspopup="true" aria-expanded="false">
                    <div class="profile-avatar-circle">
                        ${avatarContent}
                        <span class="avatar-status-dot"></span>
                    </div>
                    <div class="profile-user-info">
                        <span class="profile-user-name">${this.escapeHtml(user.name.split(' ')[0])}</span>
                        <span class="profile-registered-badge">
                            <svg viewBox="0 0 16 16" width="10" height="10" fill="currentColor">
                                <path d="M13.485 1.431a1.473 1.473 0 0 1 2.104 2.062l-7.84 9.801a1.473 1.473 0 0 1-2.12.04L1.43 9.135a1.473 1.473 0 1 1 2.08-2.084l3.111 3.11 6.864-8.73z"/>
                            </svg>
                            Registered
                        </span>
                    </div>
                    <span class="profile-chevron">▾</span>
                </button>

                <div class="profile-dropdown-card" id="eventoraProfileDropdown">
                    <div class="dropdown-header">
                        <div class="dropdown-avatar-large">
                            ${avatarContent}
                        </div>
                        <div class="dropdown-details">
                            <h4 class="dropdown-name">${this.escapeHtml(user.name)}</h4>
                            <p class="dropdown-email">${this.escapeHtml(user.email)}</p>
                            <div class="dropdown-badges">
                                <span class="badge-status-registered">✓ Registered Member</span>
                                ${providerIcon}
                            </div>
                        </div>
                    </div>

                    <div class="dropdown-divider"></div>

                    <div class="dropdown-actions">
                        <button type="button" class="dropdown-btn switch-account-action" id="dropdownSwitchAccountBtn">
                            <span class="dropdown-btn-icon">🔀</span>
                            <div class="dropdown-btn-text">
                                <strong>Login with Other Account</strong>
                                <small>Switch to another profile</small>
                            </div>
                        </button>

                        <button type="button" class="dropdown-btn google-action" id="dropdownGoogleBtn">
                            <span class="dropdown-btn-icon">
                                <svg viewBox="0 0 24 24" width="18" height="18">
                                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                                </svg>
                            </span>
                            <div class="dropdown-btn-text">
                                <strong>Use Google Account</strong>
                                <small>Sign in or switch with Google</small>
                            </div>
                        </button>

                        <a href="bookings.html" class="dropdown-btn">
                            <span class="dropdown-btn-icon">📋</span>
                            <div class="dropdown-btn-text">
                                <strong>My Bookings</strong>
                                <small>View planned celebrations</small>
                            </div>
                        </a>
                    </div>

                    <div class="dropdown-footer">
                        <button type="button" class="dropdown-logout-btn" id="dropdownLogoutBtn">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                                <path d="M16 13v-2H7V8l-5 4 5 4v-3h9zM20 3h-9c-1.1 0-2 .9-2 2v4h2V5h9v14h-9v-4H9v4c0 1.1.9 2 2 2h9c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/>
                            </svg>
                            Log Out
                        </button>
                    </div>
                </div>
            `;
        },

        /**
         * Bind click events for dropdown trigger, logout, switch account, google auth
         */
        bindWidgetEvents: function (widget, currentUser) {
            const trigger = widget.querySelector('#eventoraProfileTrigger');
            const dropdown = widget.querySelector('#eventoraProfileDropdown');
            const switchBtn = widget.querySelector('#dropdownSwitchAccountBtn');
            const googleBtn = widget.querySelector('#dropdownGoogleBtn');
            const logoutBtn = widget.querySelector('#dropdownLogoutBtn');

            // Toggle dropdown
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                const isOpen = dropdown.classList.contains('show');
                this.closeAllDropdowns();
                if (!isOpen) {
                    dropdown.classList.add('show');
                    trigger.classList.add('active');
                    trigger.setAttribute('aria-expanded', 'true');
                }
            });

            // Close on click outside
            document.addEventListener('click', (e) => {
                if (!widget.contains(e.target)) {
                    dropdown.classList.remove('show');
                    trigger.classList.remove('active');
                    trigger.setAttribute('aria-expanded', 'false');
                }
            });

            // Logout action
            if (logoutBtn) {
                logoutBtn.addEventListener('click', () => {
                    this.logout();
                });
            }

            // Switch account action
            if (switchBtn) {
                switchBtn.addEventListener('click', () => {
                    dropdown.classList.remove('show');
                    trigger.classList.remove('active');
                    this.openSwitchAccountModal();
                });
            }

            // Google account action
            if (googleBtn) {
                googleBtn.addEventListener('click', () => {
                    dropdown.classList.remove('show');
                    trigger.classList.remove('active');
                    this.openGoogleModal();
                });
            }
        },

        closeAllDropdowns: function () {
            document.querySelectorAll('.profile-dropdown-card.show').forEach(el => el.classList.remove('show'));
            document.querySelectorAll('.profile-trigger-btn.active').forEach(el => {
                el.classList.remove('active');
                el.setAttribute('aria-expanded', 'false');
            });
        },

        /**
         * Create or ensure Modals exist in DOM
         */
        ensureModals: function () {
            if (!document.getElementById('switchAccountModalOverlay')) {
                const switchModal = document.createElement('div');
                switchModal.id = 'switchAccountModalOverlay';
                switchModal.className = 'eventora-modal-overlay';
                switchModal.innerHTML = `
                    <div class="eventora-modal-card">
                        <button type="button" class="modal-close-btn" id="closeSwitchModal">&times;</button>
                        <div class="modal-header">
                            <div class="modal-icon">🔀</div>
                            <h3>Login with Other Account</h3>
                            <p>Choose a saved profile or login with another account</p>
                        </div>

                        <div class="saved-accounts-list" id="savedAccountsContainer">
                            <!-- Populated dynamically -->
                        </div>

                        <div class="modal-divider"><span>OR SIGN IN</span></div>

                        <form class="modal-quick-login-form" id="quickLoginForm">
                            <input type="email" id="quickLoginEmail" placeholder="Enter account email" required>
                            <input type="password" id="quickLoginPassword" placeholder="Enter password" required>
                            <button type="submit" class="modal-primary-btn">Sign In to Account ✨</button>
                        </form>

                        <div class="modal-footer-links">
                            <a href="login.html">Go to full login page</a> • 
                            <a href="register.html">Create new account</a>
                        </div>
                    </div>
                `;
                document.body.appendChild(switchModal);

                // Bind close events
                switchModal.querySelector('#closeSwitchModal').addEventListener('click', () => {
                    switchModal.classList.remove('active');
                });
                switchModal.addEventListener('click', (e) => {
                    if (e.target === switchModal) switchModal.classList.remove('active');
                });

                // Quick login form submission
                switchModal.querySelector('#quickLoginForm').addEventListener('submit', (e) => {
                    e.preventDefault();
                    const email = switchModal.querySelector('#quickLoginEmail').value;
                    const pass = switchModal.querySelector('#quickLoginPassword').value;
                    const res = this.login(email, pass);
                    if (res.success) {
                        this.showToast(`Logged in as ${res.user.name}!`, 'success');
                        switchModal.classList.remove('active');
                        setTimeout(() => window.location.reload(), 600);
                    } else {
                        this.showToast(res.message, 'error');
                    }
                });
            }

            if (!document.getElementById('googleModalOverlay')) {
                const googleModal = document.createElement('div');
                googleModal.id = 'googleModalOverlay';
                googleModal.className = 'eventora-modal-overlay';
                googleModal.innerHTML = `
                    <div class="eventora-modal-card google-modal-card">
                        <button type="button" class="modal-close-btn" id="closeGoogleModal">&times;</button>
                        <div class="google-modal-header">
                            <svg viewBox="0 0 24 24" width="36" height="36">
                                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                            </svg>
                            <h3>Sign in with Google</h3>
                            <p>Choose a Google account to continue to Eventora</p>
                        </div>

                        <div class="google-account-list">
                            <button type="button" class="google-account-choice" data-name="Jane Doe" data-email="jane.doe@gmail.com">
                                <div class="google-user-avatar" style="background:#e8710a;">J</div>
                                <div class="google-user-meta">
                                    <strong>Jane Doe</strong>
                                    <span>jane.doe@gmail.com</span>
                                </div>
                            </button>

                            <button type="button" class="google-account-choice" data-name="Event Planner" data-email="planner.eventora@gmail.com">
                                <div class="google-user-avatar" style="background:#1a73e8;">E</div>
                                <div class="google-user-meta">
                                    <strong>Event Planner</strong>
                                    <span>planner.eventora@gmail.com</span>
                                </div>
                            </button>
                        </div>

                        <div class="modal-divider"><span>OR CUSTOM GOOGLE ACCOUNT</span></div>

                        <form class="custom-google-form" id="customGoogleForm">
                            <input type="text" id="googleCustomName" placeholder="Your Google Name" required>
                            <input type="email" id="googleCustomEmail" placeholder="your.name@gmail.com" required>
                            <button type="submit" class="google-signin-btn">
                                Continue with this Google Account
                            </button>
                        </form>
                    </div>
                `;
                document.body.appendChild(googleModal);

                googleModal.querySelector('#closeGoogleModal').addEventListener('click', () => {
                    googleModal.classList.remove('active');
                });
                googleModal.addEventListener('click', (e) => {
                    if (e.target === googleModal) googleModal.classList.remove('active');
                });

                // Preset accounts
                googleModal.querySelectorAll('.google-account-choice').forEach(choice => {
                    choice.addEventListener('click', () => {
                        const name = choice.getAttribute('data-name');
                        const email = choice.getAttribute('data-email');
                        const user = this.loginWithGoogle({ name, email });
                        this.showToast(`Signed in with Google as ${user.name}!`, 'success');
                        googleModal.classList.remove('active');
                        setTimeout(() => window.location.reload(), 600);
                    });
                });

                // Custom google input
                googleModal.querySelector('#customGoogleForm').addEventListener('submit', (e) => {
                    e.preventDefault();
                    const name = googleModal.querySelector('#googleCustomName').value;
                    const email = googleModal.querySelector('#googleCustomEmail').value;
                    const user = this.loginWithGoogle({ name, email });
                    this.showToast(`Signed in with Google as ${user.name}!`, 'success');
                    googleModal.classList.remove('active');
                    setTimeout(() => window.location.reload(), 600);
                });
            }
        },

        /**
         * Open the Switch Account modal and populate saved accounts
         */
        openSwitchAccountModal: function () {
            this.ensureModals();
            const modal = document.getElementById('switchAccountModalOverlay');
            const container = modal.querySelector('#savedAccountsContainer');
            const users = this.getAllUsers();
            const current = this.getCurrentUser();

            if (!users.length) {
                container.innerHTML = `<p class="no-accounts-msg">No other saved accounts found. Enter details below or register a new account.</p>`;
            } else {
                container.innerHTML = users.map(u => {
                    const isCurrent = current && current.email.toLowerCase() === u.email.toLowerCase();
                    return `
                        <div class="saved-account-row ${isCurrent ? 'current' : ''}">
                            <div class="saved-account-avatar">${u.initials || this.getInitials(u.name)}</div>
                            <div class="saved-account-info">
                                <strong>${this.escapeHtml(u.name)}</strong>
                                <span>${this.escapeHtml(u.email)}</span>
                            </div>
                            ${isCurrent
                                ? `<span class="current-label">Current</span>`
                                : `<button type="button" class="switch-to-btn" data-email="${u.email}">Switch</button>`
                            }
                        </div>
                    `;
                }).join('');

                container.querySelectorAll('.switch-to-btn').forEach(b => {
                    b.addEventListener('click', () => {
                        const email = b.getAttribute('data-email');
                        this.switchAccount(email);
                    });
                });
            }

            modal.classList.add('active');
        },

        /**
         * Open Google sign-in modal
         */
        openGoogleModal: function () {
            this.ensureModals();
            const modal = document.getElementById('googleModalOverlay');
            modal.classList.add('active');
        },

        escapeHtml: function (str) {
            if (!str) return '';
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        },

        /**
         * Get the contextual search category based on current URL
         */
        getPageContext: function () {
            const path = window.location.pathname.toLowerCase();
            if (path.includes('vendor-detail')) return 'VENDOR_DETAIL';
            if (path.includes('vendors')) return 'VENDORS';
            if (path.includes('decoration')) return 'DECORATION';
            if (path.includes('catering')) return 'CATERING';
            if (path.includes('photography')) return 'PHOTOGRAPHY';
            if (path.includes('music')) return 'MUSIC';
            if (path.includes('venue')) return 'VENUE';
            if (path.includes('services')) return 'SERVICES';
            if (path.includes('bookings')) return 'BOOKINGS';
            return 'HOME';
        },

        /**
         * Initialize contextual small search icon in navbar & search overlay modal
         */
        initSearchModal: function () {
            const context = this.getPageContext();

            // 1. Ensure small search icon is in the navbar
            const navbars = document.querySelectorAll('.navbar');
            navbars.forEach(navbar => {
                if (!navbar.querySelector('.nav-search-btn')) {
                    const searchBtn = document.createElement('button');
                    searchBtn.type = 'button';
                    searchBtn.className = 'nav-search-btn';
                    searchBtn.id = 'navSearchTrigger';
                    searchBtn.title = 'Search Eventora';
                    searchBtn.setAttribute('aria-label', 'Search');
                    searchBtn.innerHTML = `
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"></circle>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                        </svg>
                    `;
                    
                    // Insert before login btn or profile widget
                    const rightEl = navbar.querySelector('.login-btn, .eventora-profile-widget, nav');
                    if (rightEl) {
                        rightEl.parentNode.insertBefore(searchBtn, rightEl.nextSibling ? rightEl : null);
                    } else {
                        navbar.appendChild(searchBtn);
                    }
                }
            });

            // 2. Build or get Search Overlay Modal DOM
            let overlay = document.getElementById('eventoraSearchOverlay');
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.id = 'eventoraSearchOverlay';
                overlay.className = 'eventora-search-overlay';
                overlay.innerHTML = `
                    <div class="eventora-search-modal">
                        <div class="search-modal-header">
                            <div class="search-modal-title">
                                <span>🔍 Search</span>
                                <span class="search-context-badge" id="searchContextBadge">${context}</span>
                            </div>
                            <button type="button" class="search-modal-close" id="closeSearchModal">&times;</button>
                        </div>

                        <div class="search-input-wrapper">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="11" cy="11" r="8"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                            </svg>
                            <input type="text" id="searchMainInput" class="search-main-input" placeholder="Search vendors, services, packages..." autocomplete="off">
                            <button type="button" id="searchClearBtn" class="search-clear-btn">&times;</button>
                        </div>

                        <div class="search-sorting-row">
                            <span>Filter & Sort Results:</span>
                            <select id="searchSortSelect" class="search-sort-select">
                                <option value="rating">Top Rated (Highest First)</option>
                                <option value="price_low">Price: Low to High</option>
                                <option value="price_high">Price: High to Low</option>
                                <option value="popularity">Most Popular</option>
                                <option value="newest">Newest</option>
                            </select>
                        </div>

                        <div class="search-chips-section" id="searchSuggestionsSection">
                            <div class="search-chips-label">
                                <span>Suggested Searches</span>
                            </div>
                            <div class="search-chips-list" id="searchSuggestionsList">
                                <span class="search-chip suggestion">Loading...</span>
                            </div>
                        </div>

                        <div class="search-chips-section" id="searchRecentSection">
                            <div class="search-chips-label">
                                <span>Recent Searches</span>
                                <button type="button" id="clearRecentBtn" style="background:none; border:none; color:#be185d; cursor:pointer; font-size:11px; font-weight:700;">Clear All</button>
                            </div>
                            <div class="search-chips-list" id="searchRecentList">
                                <span style="font-size:12px; color:#8d7997;">No recent searches</span>
                            </div>
                        </div>

                        <div class="search-results-container" id="searchResultsContainer">
                            <div style="text-align:center; padding:30px 10px; color:#7d6b88; font-size:13.5px;">
                                Type above or click a suggestion to search vendors, services, and packages ✨
                            </div>
                        </div>
                    </div>
                `;
                document.body.appendChild(overlay);

                // Close handlers
                overlay.querySelector('#closeSearchModal').addEventListener('click', () => {
                    overlay.classList.remove('active');
                });
                overlay.addEventListener('click', (e) => {
                    if (e.target === overlay) overlay.classList.remove('active');
                });
                document.addEventListener('keydown', (e) => {
                    if (e.key === 'Escape' && overlay.classList.contains('active')) {
                        overlay.classList.remove('active');
                    }
                });

                // Clear button inside search input
                const clearBtn = overlay.querySelector('#searchClearBtn');
                const searchInput = overlay.querySelector('#searchMainInput');
                searchInput.addEventListener('input', () => {
                    clearBtn.style.display = searchInput.value ? 'block' : 'none';
                    EventoraAuth.performSearch(searchInput.value);
                });
                clearBtn.addEventListener('click', () => {
                    searchInput.value = '';
                    clearBtn.style.display = 'none';
                    EventoraAuth.performSearch('');
                    searchInput.focus();
                });

                // Sort change
                overlay.querySelector('#searchSortSelect').addEventListener('change', () => {
                    EventoraAuth.performSearch(searchInput.value);
                });

                // Clear recent searches
                overlay.querySelector('#clearRecentBtn').addEventListener('click', () => {
                    EventoraAuth.clearRecentSearches();
                });
            }

            // Bind triggers
            document.querySelectorAll('.nav-search-btn, #navSearchTrigger').forEach(btn => {
                btn.onclick = () => EventoraAuth.openSearchModal();
            });
        },

        /**
         * Open the contextual search modal and load suggestions & recents
         */
        openSearchModal: function () {
            this.ensureModals();
            this.initSearchModal();
            const overlay = document.getElementById('eventoraSearchOverlay');
            if (!overlay) return;

            const context = this.getPageContext();
            const badge = overlay.querySelector('#searchContextBadge');
            const searchInput = overlay.querySelector('#searchMainInput');
            if (badge) badge.textContent = context.replace('_', ' ');

            // Customize placeholder by context
            if (context === 'VENDORS') {
                searchInput.placeholder = 'Search vendors by name, location, category...';
            } else if (context === 'VENDOR_DETAIL') {
                searchInput.placeholder = 'Search this vendor\'s services, designs, packages...';
            } else if (context === 'BOOKINGS') {
                searchInput.placeholder = 'Search your bookings by vendor name or status...';
            } else if (context === 'DECORATION') {
                searchInput.placeholder = 'Search stage, floral, wedding decoration packages...';
            } else if (context === 'CATERING') {
                searchInput.placeholder = 'Search buffet, live counters, vegetarian catering...';
            } else if (context === 'PHOTOGRAPHY') {
                searchInput.placeholder = 'Search candid wedding, pre-wedding photography...';
            } else {
                searchInput.placeholder = 'Search vendors, services, venues, packages...';
            }

            // Load contextual suggestions (3-5 items)
            this.loadSearchSuggestions(context);

            // Load recent searches (up to 5 items)
            this.loadRecentSearches(context);

            overlay.classList.add('active');
            setTimeout(() => searchInput.focus(), 80);
        },

        /**
         * Fetch 3-5 suggestions for the current page context
         */
        loadSearchSuggestions: function (context) {
            const listEl = document.getElementById('searchSuggestionsList');
            if (!listEl) return;

            fetch(`/api/search/suggestions?context=${encodeURIComponent(context)}`)
                .then(res => res.json())
                .then(res => {
                    if (res.success && res.data && res.data.length) {
                        listEl.innerHTML = res.data.slice(0, 5).map(s => `
                            <button type="button" class="search-chip suggestion" onclick="EventoraAuth.applySearchChip('${this.escapeHtml(s)}')">
                                ✨ ${this.escapeHtml(s)}
                            </button>
                        `).join('');
                    } else {
                        // Fallback contextual suggestions
                        const fallbacks = {
                            HOME: ['Wedding decoration', 'Catering buffet', 'Photography studios', 'Grand venues'],
                            VENDORS: ['Dream Decor', 'Pixel Moments', 'Royal Feast', 'Beat Masters DJ'],
                            DECORATION: ['Stage decoration', 'Floral mandap', 'Birthday balloons', 'Luxury backdrop'],
                            BOOKINGS: ['Pending bookings', 'Confirmed events', 'Completed celebrations']
                        };
                        const items = fallbacks[context] || fallbacks.HOME;
                        listEl.innerHTML = items.map(s => `
                            <button type="button" class="search-chip suggestion" onclick="EventoraAuth.applySearchChip('${this.escapeHtml(s)}')">
                                ✨ ${this.escapeHtml(s)}
                            </button>
                        `).join('');
                    }
                })
                .catch(() => {
                    listEl.innerHTML = `
                        <button type="button" class="search-chip suggestion" onclick="EventoraAuth.applySearchChip('Stage decoration')">✨ Stage decoration</button>
                        <button type="button" class="search-chip suggestion" onclick="EventoraAuth.applySearchChip('Wedding photography')">✨ Wedding photography</button>
                        <button type="button" class="search-chip suggestion" onclick="EventoraAuth.applySearchChip('Catering buffet')">✨ Catering buffet</button>
                    `;
                });
        },

        /**
         * Fetch up to 5 recent searches
         */
        loadRecentSearches: function (context) {
            const listEl = document.getElementById('searchRecentList');
            if (!listEl) return;

            // Also check localStorage
            let localRecents = [];
            try {
                localRecents = JSON.parse(localStorage.getItem('eventora_recent_searches') || '[]');
            } catch (e) {
                localRecents = [];
            }

            fetch(`/api/search/recent?context=${encodeURIComponent(context)}`)
                .then(res => res.json())
                .then(res => {
                    let items = [];
                    if (res.success && res.data && res.data.length) {
                        items = res.data;
                    } else {
                        items = localRecents;
                    }

                    if (items && items.length) {
                        listEl.innerHTML = items.slice(0, 5).map(r => `
                            <button type="button" class="search-chip" onclick="EventoraAuth.applySearchChip('${this.escapeHtml(r)}')">
                                🕒 ${this.escapeHtml(r)}
                            </button>
                        `).join('');
                    } else {
                        listEl.innerHTML = `<span style="font-size:12px; color:#8d7997;">No recent searches recorded</span>`;
                    }
                })
                .catch(() => {
                    if (localRecents.length) {
                        listEl.innerHTML = localRecents.slice(0, 5).map(r => `
                            <button type="button" class="search-chip" onclick="EventoraAuth.applySearchChip('${this.escapeHtml(r)}')">
                                🕒 ${this.escapeHtml(r)}
                            </button>
                        `).join('');
                    } else {
                        listEl.innerHTML = `<span style="font-size:12px; color:#8d7997;">No recent searches recorded</span>`;
                    }
                });
        },

        /**
         * Save recent search both to server and local storage
         */
        recordRecentSearch: function (query) {
            if (!query || !query.trim()) return;
            const q = query.trim();
            const context = this.getPageContext();

            // LocalStorage
            try {
                let recents = JSON.parse(localStorage.getItem('eventora_recent_searches') || '[]');
                recents = recents.filter(x => x.toLowerCase() !== q.toLowerCase());
                recents.unshift(q);
                if (recents.length > 5) recents = recents.slice(0, 5);
                localStorage.setItem('eventora_recent_searches', JSON.stringify(recents));
            } catch (e) {}

            // Server
            fetch('/api/search/recent', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query: q, pageContext: context })
            }).catch(() => {});
        },

        /**
         * Clear recent searches
         */
        clearRecentSearches: function () {
            try {
                localStorage.removeItem('eventora_recent_searches');
            } catch (e) {}

            fetch('/api/search/recent', { method: 'DELETE' }).catch(() => {});
            const listEl = document.getElementById('searchRecentList');
            if (listEl) {
                listEl.innerHTML = `<span style="font-size:12px; color:#8d7997;">Recent searches cleared</span>`;
            }
        },

        /**
         * Apply a chip search
         */
        applySearchChip: function (text) {
            const input = document.getElementById('searchMainInput');
            if (input) {
                input.value = text;
                const clearBtn = document.getElementById('searchClearBtn');
                if (clearBtn) clearBtn.style.display = 'block';
                this.performSearch(text);
                this.recordRecentSearch(text);
            }
        },

        /**
         * Live Dynamic Search Query
         */
        performSearch: function (query) {
            const container = document.getElementById('searchResultsContainer');
            if (!container) return;

            const q = (query || '').trim();
            const sort = document.getElementById('searchSortSelect')?.value || 'rating';

            // If user is on bookings.html, dynamically filter booking items on page too!
            if (window.location.pathname.includes('bookings.html')) {
                const bookingCards = document.querySelectorAll('.booking-item-card');
                if (bookingCards.length) {
                    bookingCards.forEach(card => {
                        const text = card.textContent.toLowerCase();
                        card.style.display = (!q || text.includes(q.toLowerCase())) ? '' : 'none';
                    });
                }
            }

            if (!q) {
                container.innerHTML = `
                    <div style="text-align:center; padding:30px 10px; color:#7d6b88; font-size:13.5px;">
                        Type above or click a suggestion to search vendors, services, and packages ✨
                    </div>
                `;
                return;
            }

            container.innerHTML = `
                <div style="text-align:center; padding:20px; color:#9b3f9d; font-size:13.5px;">
                    Searching Eventora directory... ✨
                </div>
            `;

            fetch(`/api/vendors?search=${encodeURIComponent(q)}&sort=${encodeURIComponent(sort)}`)
                .then(res => res.json())
                .then(res => {
                    const vendors = (res && res.data) ? res.data : [];
                    if (!vendors.length) {
                        container.innerHTML = `
                            <div style="text-align:center; padding:30px 10px; color:#7d6b88; font-size:13.5px;">
                                No matches found for "<strong>${this.escapeHtml(q)}</strong>".<br>
                                Try searching for "Decoration", "Photography", "Catering", or "Visakhapatnam".
                            </div>
                        `;
                        return;
                    }

                    container.innerHTML = vendors.map(v => {
                        const iconMap = {
                            'Decoration': '✨',
                            'Photography': '📸',
                            'Catering': '🍽️',
                            'Music/DJ': '🎵',
                            'Venue': '🏛️',
                            'Makeup': '💄'
                        };
                        const icon = iconMap[v.category] || '⭐';
                        const price = v.startingPrice ? 'From ₹' + Number(v.startingPrice).toLocaleString() : 'Custom Quote';

                        return `
                            <a href="vendor-detail.html?id=${v.id}" class="search-result-item" onclick="EventoraAuth.recordRecentSearch('${this.escapeHtml(q)}')">
                                <div class="search-result-left">
                                    <div class="search-result-icon">${icon}</div>
                                    <div>
                                        <div class="search-result-title">${this.escapeHtml(v.businessName)}</div>
                                        <div class="search-result-sub">${this.escapeHtml(v.category)} • 📍 ${this.escapeHtml(v.location || 'Visakhapatnam')} • ⭐ ${v.rating || 5.0}</div>
                                    </div>
                                </div>
                                <div class="search-result-price">${price} →</div>
                            </a>
                        `;
                    }).join('');
                })
                .catch(() => {
                    container.innerHTML = `
                        <div style="text-align:center; padding:20px; color:#be123c; font-size:13.5px;">
                            Unable to fetch results. Please try again.
                        </div>
                    `;
                });
        },

        /**
         * Open Development Simulation Milestone Payment Modal (50% Advance / 50% Remaining)
         */
        openPaymentModal: function (opts) {
            this.ensureModals();
            const bookingId = opts.bookingId;
            const paymentType = opts.paymentType || 'ADVANCE'; // ADVANCE or FINAL
            const amount = Number(opts.amount || 0);
            const onSuccess = opts.onSuccess || function () {};

            let modal = document.getElementById('eventoraPaymentDialogOverlay');
            if (modal) modal.remove();

            modal = document.createElement('div');
            modal.id = 'eventoraPaymentDialogOverlay';
            modal.className = 'eventora-modal-dialog-overlay';
            modal.innerHTML = `
                <div class="eventora-modal-dialog-card">
                    <button type="button" class="modal-dialog-close" id="closePaymentModal">&times;</button>
                    
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:12px;">
                        <div style="width:42px; height:42px; border-radius:12px; background:linear-gradient(135deg, #eff6ff, #dbeafe); color:#2563eb; display:flex; align-items:center; justify-content:center; font-size:22px;">💳</div>
                        <div>
                            <h3 style="font-size:20px; color:#24152f; margin:0;">Eventora Payment</h3>
                            <span style="font-size:12px; font-weight:800; color:#2563eb;">50/50 MILESTONE PROTECTION</span>
                        </div>
                    </div>

                    <!-- Development simulation banner -->
                    <div style="background:#fffbeb; border:1px solid #fde68a; border-radius:14px; padding:12px 14px; font-size:12.5px; color:#92400e; line-height:1.5; margin-bottom:18px;">
                        <strong>⚠️ Testing Simulation Mode:</strong> Real payment gateway is not configured for local development. This simulation securely verifies the milestone and records the transaction in MySQL.
                    </div>

                    <div style="background:#faf7ff; border:1.5px solid #e0c8eb; border-radius:16px; padding:18px; margin-bottom:20px;">
                        <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:14px; color:#6e5878;">
                            <span>Booking Reference:</span>
                            <strong style="color:#9b3f9d;">#EVT-${bookingId}</strong>
                        </div>
                        <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:14px; color:#6e5878;">
                            <span>Payment Milestone:</span>
                            <strong style="color:#24152f;">${paymentType === 'ADVANCE' ? '50% Advance (Booking Confirmation)' : '50% Remaining (Event Completed)'}</strong>
                        </div>
                        <div style="display:flex; justify-content:space-between; font-size:18px; font-weight:800; color:#065f46; border-top:1px solid #e5d4ed; padding-top:10px; margin-top:8px;">
                            <span>Amount to Pay:</span>
                            <span>₹${amount.toLocaleString()}</span>
                        </div>
                    </div>

                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-size:13px; font-weight:700; color:#382442; margin-bottom:10px;">Select Payment Method</label>
                        <div style="display:flex; flex-direction:column; gap:8px;">
                            <label style="display:flex; align-items:center; gap:10px; padding:10px 14px; border:1.5px solid #e0c8eb; border-radius:12px; cursor:pointer; background:#fff;">
                                <input type="radio" name="payMethod" value="UPI" checked style="accent-color:#2563eb;">
                                <span style="font-weight:700; font-size:14px;">UPI (Google Pay / PhonePe / Paytm)</span>
                            </label>
                            <label style="display:flex; align-items:center; gap:10px; padding:10px 14px; border:1.5px solid #e0c8eb; border-radius:12px; cursor:pointer; background:#fff;">
                                <input type="radio" name="payMethod" value="CARD" style="accent-color:#2563eb;">
                                <span style="font-weight:700; font-size:14px;">Debit / Credit Card (Visa / Mastercard)</span>
                            </label>
                            <label style="display:flex; align-items:center; gap:10px; padding:10px 14px; border:1.5px solid #e0c8eb; border-radius:12px; cursor:pointer; background:#fff;">
                                <input type="radio" name="payMethod" value="NET_BANKING" style="accent-color:#2563eb;">
                                <span style="font-weight:700; font-size:14px;">Net Banking (SBI / HDFC / ICICI)</span>
                            </label>
                        </div>
                    </div>

                    <div id="paymentErrorBox" style="display:none; color:#be123c; background:#ffe4e6; border:1px solid #fecdd3; padding:10px; border-radius:10px; font-size:13px; margin-bottom:14px;"></div>

                    <button type="button" id="confirmPaymentBtn" style="width:100%; padding:14px; background:linear-gradient(135deg, #10b981, #059669); color:#fff; border:none; border-radius:16px; font-size:16px; font-weight:800; cursor:pointer; box-shadow:0 4px 14px rgba(16, 185, 129, 0.3);">
                        Confirm & Record Payment (₹${amount.toLocaleString()}) →
                    </button>
                </div>
            `;
            document.body.appendChild(modal);

            modal.querySelector('#closePaymentModal').addEventListener('click', () => modal.remove());
            modal.addEventListener('click', (e) => {
                if (e.target === modal) modal.remove();
            });

            const confirmBtn = modal.querySelector('#confirmPaymentBtn');
            const errBox = modal.querySelector('#paymentErrorBox');

            confirmBtn.addEventListener('click', () => {
                const method = modal.querySelector('input[name="payMethod"]:checked')?.value || 'UPI';
                confirmBtn.disabled = true;
                confirmBtn.textContent = 'Processing Transaction... ⏳';
                errBox.style.display = 'none';

                fetch('/api/payments', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        bookingId: bookingId,
                        paymentType: paymentType,
                        amount: amount,
                        paymentMethod: method,
                        notes: `Simulated ${paymentType} payment via ${method}`
                    })
                })
                .then(res => res.json())
                .then(res => {
                    if (res.success && res.data) {
                        modal.remove();
                        EventoraAuth.showToast(`🎉 Payment recorded successfully! Ref: ${res.data.transactionReference}`, 'success');
                        onSuccess(res.data);
                    } else {
                        confirmBtn.disabled = false;
                        confirmBtn.textContent = `Confirm & Record Payment (₹${amount.toLocaleString()}) →`;
                        errBox.textContent = res.message || 'Payment processing failed. Please try again.';
                        errBox.style.display = 'block';
                    }
                })
                .catch(err => {
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = `Confirm & Record Payment (₹${amount.toLocaleString()}) →`;
                    errBox.textContent = 'Unable to connect to payment server. Please try again.';
                    errBox.style.display = 'block';
                });
            });

            setTimeout(() => modal.classList.add('active'), 10);
        },

        /**
         * Open Dynamic Category Review Modal (Decoration, Catering, Photography, Venue, Music/DJ, Customer)
         */
        openReviewModal: function (opts) {
            this.ensureModals();
            const bookingId = opts.bookingId;
            const reviewType = opts.reviewType || 'CUSTOMER_TO_VENDOR';
            const targetName = opts.targetName || (reviewType === 'CUSTOMER_TO_VENDOR' ? 'Vendor' : 'Customer');
            const category = opts.category || (reviewType === 'CUSTOMER_TO_VENDOR' ? 'Decoration' : 'Customer');
            const onSuccess = opts.onSuccess || function () {};

            let modal = document.getElementById('eventoraReviewDialogOverlay');
            if (modal) modal.remove();

            modal = document.createElement('div');
            modal.id = 'eventoraReviewDialogOverlay';
            modal.className = 'eventora-modal-dialog-overlay';
            modal.innerHTML = `
                <div class="eventora-modal-dialog-card">
                    <button type="button" class="modal-dialog-close" id="closeReviewModal">&times;</button>
                    
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">
                        <div style="width:42px; height:42px; border-radius:12px; background:linear-gradient(135deg, #fef3c7, #fde68a); color:#d97706; display:flex; align-items:center; justify-content:center; font-size:22px;">⭐</div>
                        <div>
                            <h3 style="font-size:20px; color:#24152f; margin:0;">${reviewType === 'CUSTOMER_TO_VENDOR' ? 'Rate & Review ' + this.escapeHtml(targetName) : 'Review Customer ' + this.escapeHtml(targetName)}</h3>
                            <span style="font-size:12px; font-weight:800; color:#d97706;">VERIFIED COMPLETED EVENT REVIEW</span>
                        </div>
                    </div>

                    <p style="font-size:13.5px; color:#6e5878; margin-bottom:18px;">
                        ${reviewType === 'CUSTOMER_TO_VENDOR' ? `Share your experience with ${this.escapeHtml(targetName)} to help other celebrants.` : `Share feedback on the customer\'s cooperation and event day experience.`}
                    </p>

                    <!-- Overall Star Rating -->
                    <div style="background:#faf7ff; border:1px solid #e0c8eb; border-radius:16px; padding:16px; text-align:center; margin-bottom:18px;">
                        <div style="font-size:13px; font-weight:800; color:#382442; margin-bottom:8px;">Overall Star Rating</div>
                        <div id="starPickerWrap" style="display:flex; justify-content:center; gap:8px; font-size:32px; cursor:pointer;">
                            <span data-star="1" style="color:#d1d5db;">★</span>
                            <span data-star="2" style="color:#d1d5db;">★</span>
                            <span data-star="3" style="color:#d1d5db;">★</span>
                            <span data-star="4" style="color:#d1d5db;">★</span>
                            <span data-star="5" style="color:#d1d5db;">★</span>
                        </div>
                        <span id="starRatingLabel" style="font-size:12.5px; font-weight:700; color:#7d6b88; margin-top:4px; display:inline-block;">Click to rate (5 = Excellent)</span>
                    </div>

                    <!-- Dynamic Category Questions -->
                    <div style="margin-bottom:18px;">
                        <h4 style="font-size:14px; font-weight:800; color:#24152f; margin-bottom:10px;">${category} Experience Assessment</h4>
                        <div id="dynamicQuestionsList" style="display:flex; flex-direction:column; gap:10px;">
                            <div style="text-align:center; padding:10px; color:#7d6b88; font-size:13px;">Loading questions...</div>
                        </div>
                    </div>

                    <!-- Comments Textarea -->
                    <div style="margin-bottom:16px;">
                        <label style="display:block; font-size:13px; font-weight:700; color:#382442; margin-bottom:6px;">Detailed Feedback</label>
                        <textarea id="reviewCommentText" placeholder="What stood out? Mention their timeliness, quality, respectfulness, or areas of improvement..." style="width:100%; min-height:85px; padding:12px; border:1.5px solid #dfd2e8; border-radius:12px; font-size:14px; font-family:inherit; outline:none; box-sizing:border-box;"></textarea>
                    </div>

                    <!-- Recommendation Toggle -->
                    <div style="margin-bottom:20px;">
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-size:13.5px; font-weight:700; color:#24152f;">
                            <input type="checkbox" id="reviewRecommendToggle" checked style="width:18px; height:18px; accent-color:#ff4f9a;">
                            <span>Would you recommend this ${reviewType === 'CUSTOMER_TO_VENDOR' ? 'vendor' : 'customer'} to others?</span>
                        </label>
                    </div>

                    <div id="reviewErrorBox" style="display:none; color:#be123c; background:#ffe4e6; border:1px solid #fecdd3; padding:10px; border-radius:10px; font-size:13px; margin-bottom:14px;"></div>

                    <button type="button" id="submitReviewBtn" style="width:100%; padding:14px; background:linear-gradient(135deg, #ff4f9a, #9b3f9d); color:#fff; border:none; border-radius:16px; font-size:16px; font-weight:800; cursor:pointer; box-shadow:0 4px 14px rgba(255, 79, 154, 0.3);">
                        Submit Review ⭐
                    </button>
                </div>
            `;
            document.body.appendChild(modal);

            modal.querySelector('#closeReviewModal').addEventListener('click', () => modal.remove());
            modal.addEventListener('click', (e) => {
                if (e.target === modal) modal.remove();
            });

            // Star Rating Logic
            let chosenRating = 5;
            const stars = modal.querySelectorAll('#starPickerWrap span');
            const starLabel = modal.querySelector('#starRatingLabel');
            const labels = ['', 'Poor (1/5)', 'Fair (2/5)', 'Good (3/5)', 'Very Good (4/5)', 'Excellent (5/5)'];

            function updateStarDisplay(val) {
                chosenRating = val;
                stars.forEach((s, idx) => {
                    s.style.color = (idx < val) ? '#f59e0b' : '#d1d5db';
                });
                starLabel.textContent = labels[val] || '';
            }
            updateStarDisplay(5);

            stars.forEach(s => {
                s.addEventListener('click', () => {
                    const val = parseInt(s.getAttribute('data-star') || '5', 10);
                    updateStarDisplay(val);
                });
            });

            // Load Dynamic Questions
            const qList = modal.querySelector('#dynamicQuestionsList');
            const targetCategory = (reviewType === 'CUSTOMER_TO_VENDOR') ? (category || 'Decoration') : 'Customer';
            const questionRatings = {};

            fetch(`/api/reviews/questions?category=${encodeURIComponent(targetCategory)}`)
                .then(res => res.json())
                .then(res => {
                    const list = (res.success && res.data && res.data.length) ? res.data : [
                        { questionKey: 'service_quality', questionText: 'Service Quality & Execution' },
                        { questionKey: 'timeliness', questionText: 'Punctuality & Timeliness' },
                        { questionKey: 'professionalism', questionText: 'Professionalism & Communication' }
                    ];

                    qList.innerHTML = list.map(q => {
                        questionRatings[q.questionKey] = 5;
                        return `
                            <div style="display:flex; justify-content:space-between; align-items:center; background:#faf7ff; padding:8px 12px; border-radius:10px; border:1px solid #f0e6f5;">
                                <span style="font-size:13px; color:#382442; font-weight:600;">${this.escapeHtml(q.questionText)}</span>
                                <div class="q-star-row" data-key="${q.questionKey}" style="display:flex; gap:3px; font-size:18px; cursor:pointer;">
                                    <span data-val="1" style="color:#f59e0b;">★</span>
                                    <span data-val="2" style="color:#f59e0b;">★</span>
                                    <span data-val="3" style="color:#f59e0b;">★</span>
                                    <span data-val="4" style="color:#f59e0b;">★</span>
                                    <span data-val="5" style="color:#f59e0b;">★</span>
                                </div>
                            </div>
                        `;
                    }).join('');

                    // Bind per-question star clicks
                    qList.querySelectorAll('.q-star-row').forEach(row => {
                        const key = row.getAttribute('data-key');
                        const rowStars = row.querySelectorAll('span');
                        rowStars.forEach(s => {
                            s.addEventListener('click', () => {
                                const val = parseInt(s.getAttribute('data-val') || '5', 10);
                                questionRatings[key] = val;
                                rowStars.forEach((st, idx) => {
                                    st.style.color = (idx < val) ? '#f59e0b' : '#d1d5db';
                                });
                            });
                        });
                    });
                })
                .catch(() => {
                    qList.innerHTML = `<span style="font-size:12.5px; color:#7d6b88;">General criteria will be applied.</span>`;
                });

            // Submit review
            const submitBtn = modal.querySelector('#submitReviewBtn');
            const errBox = modal.querySelector('#reviewErrorBox');

            submitBtn.addEventListener('click', () => {
                const comment = modal.querySelector('#reviewCommentText').value.trim();
                const recommended = modal.querySelector('#reviewRecommendToggle').checked;

                submitBtn.disabled = true;
                submitBtn.textContent = 'Submitting Feedback... ⭐';
                errBox.style.display = 'none';

                const endpoint = (reviewType === 'CUSTOMER_TO_VENDOR') ? '/api/reviews/customer' : '/api/reviews/vendor';

                fetch(endpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        bookingId: bookingId,
                        overallRating: chosenRating,
                        comment: comment,
                        recommended: recommended,
                        questionRatings: questionRatings
                    })
                })
                .then(res => res.json())
                .then(res => {
                    if (res.success) {
                        modal.remove();
                        EventoraAuth.showToast('⭐ Thank you! Your review has been recorded.', 'success');
                        onSuccess(res.data);
                    } else {
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Submit Review ⭐';
                        errBox.textContent = res.message || 'Unable to submit review. Please try again.';
                        errBox.style.display = 'block';
                    }
                })
                .catch(err => {
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Submit Review ⭐';
                    errBox.textContent = 'Unable to connect to server. Please try again.';
                    errBox.style.display = 'block';
                });
            });

            setTimeout(() => modal.classList.add('active'), 10);
        }
    };

    window.EventoraAuth = EventoraAuth;

    // Automatically initialize navbar auth and search modal when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            EventoraAuth.initNavbarAuth();
            EventoraAuth.initSearchModal();
        });
    } else {
        EventoraAuth.initNavbarAuth();
        EventoraAuth.initSearchModal();
    }

})(window);
