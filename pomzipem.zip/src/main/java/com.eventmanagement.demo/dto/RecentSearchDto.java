package com.eventmanagement.demo.dto;

import jakarta.validation.constraints.NotBlank;

public class RecentSearchDto {

    @NotBlank(message = "Search query cannot be blank")
    private String query;

    private String pageContext = "HOME";

    public RecentSearchDto() {
    }

    public RecentSearchDto(String query, String pageContext) {
        this.query = query;
        this.pageContext = pageContext;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getPageContext() {
        return pageContext;
    }

    public void setPageContext(String pageContext) {
        this.pageContext = pageContext;
    }
}
