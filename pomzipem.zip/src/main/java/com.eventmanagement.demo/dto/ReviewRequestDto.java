package com.eventmanagement.demo.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import java.util.Map;

public class ReviewRequestDto {

    private Long bookingId;

    @JsonAlias({"overallRating", "rating"})
    @Min(value = 1, message = "Rating must be at least 1")
    @Max(value = 5, message = "Rating must be at most 5")
    private Integer rating = 5;

    private String comment;

    private Boolean recommended = true;

    @JsonAlias({"questionRatings", "categoryScores"})
    private Map<String, Integer> categoryScores;

    public ReviewRequestDto() {
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Integer getRating() {
        return rating != null ? rating : 5;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public Integer getOverallRating() {
        return getRating();
    }

    public void setOverallRating(Integer overallRating) {
        this.rating = overallRating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Boolean getRecommended() {
        return recommended;
    }

    public void setRecommended(Boolean recommended) {
        this.recommended = recommended;
    }

    public Map<String, Integer> getCategoryScores() {
        return categoryScores;
    }

    public void setCategoryScores(Map<String, Integer> categoryScores) {
        this.categoryScores = categoryScores;
    }

    public Map<String, Integer> getQuestionRatings() {
        return categoryScores;
    }

    public void setQuestionRatings(Map<String, Integer> questionRatings) {
        this.categoryScores = questionRatings;
    }
}
