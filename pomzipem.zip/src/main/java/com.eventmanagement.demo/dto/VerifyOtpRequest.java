package com.eventmanagement.demo.dto;

import jakarta.validation.constraints.NotBlank;

public class VerifyOtpRequest {

    private String email;
    private String token;

    @NotBlank(message = "Verification code is required")
    private String otp;

    public VerifyOtpRequest() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }
}
