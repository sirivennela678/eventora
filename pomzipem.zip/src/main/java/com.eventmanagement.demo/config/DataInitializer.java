package com.eventmanagement.demo.config;

import com.eventmanagement.demo.model.*;
import com.eventmanagement.demo.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

    private final UserRepository userRepository;
    private final VendorRepository vendorRepository;
    private final ServiceRepository serviceRepository;
    private final DesignPackageRepository packageRepository;
    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;
    private final ReviewRepository reviewRepository;
    private final ReviewQuestionRepository questionRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository,
                           VendorRepository vendorRepository,
                           ServiceRepository serviceRepository,
                           DesignPackageRepository packageRepository,
                           BookingRepository bookingRepository,
                           PaymentRepository paymentRepository,
                           ReviewRepository reviewRepository,
                           ReviewQuestionRepository questionRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.vendorRepository = vendorRepository;
        this.serviceRepository = serviceRepository;
        this.packageRepository = packageRepository;
        this.bookingRepository = bookingRepository;
        this.paymentRepository = paymentRepository;
        this.reviewRepository = reviewRepository;
        this.questionRepository = questionRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        logger.info("Checking Eventora database initialization...");

        // 1. Initialize Review Questions
        initReviewQuestions();

        // 2. Initialize Seed Users
        User customer = initCustomer();
        User vendorDecorUser = initVendorDecorUser();
        User vendorPhotoUser = initVendorPhotoUser();
        User vendorCateringUser = initVendorCateringUser();
        initAdminUser();

        // 3. Initialize Vendors & Catalog
        if (vendorRepository.count() == 0) {
            initVendorsAndCatalog(vendorDecorUser, vendorPhotoUser, vendorCateringUser, customer);
        }

        logger.info("Eventora database seed check complete.");
    }

    private void initReviewQuestions() {
        if (questionRepository.count() > 0) return;

        List<ReviewQuestion> questions = Arrays.asList(
                // DECORATION
                new ReviewQuestion("Decoration", "design_quality", "Design Quality & Aesthetic Appeal", 1),
                new ReviewQuestion("Decoration", "expectation_match", "Design Matching Expectation", 2),
                new ReviewQuestion("Decoration", "decoration_craft", "Decoration Quality & Finishing", 3),
                new ReviewQuestion("Decoration", "timeliness", "Timeliness & Punctuality", 4),
                new ReviewQuestion("Decoration", "professionalism", "Professionalism & Communication", 5),
                new ReviewQuestion("Decoration", "service_availability", "Service Reliability & Availability", 6),
                new ReviewQuestion("Decoration", "respectful_behavior", "Respectful & Courteous Behavior", 7),

                // CATERING
                new ReviewQuestion("Catering", "food_quality", "Food Quality & Freshness", 1),
                new ReviewQuestion("Catering", "taste", "Taste & Flavor", 2),
                new ReviewQuestion("Catering", "variety", "Menu Variety & Options", 3),
                new ReviewQuestion("Catering", "timeliness", "Serving Timeliness", 4),
                new ReviewQuestion("Catering", "hygiene", "Hygiene & Cleanliness", 5),
                new ReviewQuestion("Catering", "professionalism", "Staff Professionalism", 6),
                new ReviewQuestion("Catering", "service_quality", "Overall Service Quality", 7),

                // PHOTOGRAPHY
                new ReviewQuestion("Photography", "photo_quality", "Photo & Video Resolution / Quality", 1),
                new ReviewQuestion("Photography", "creativity", "Creativity & Shot Composition", 2),
                new ReviewQuestion("Photography", "timeliness", "Punctuality on Event Day", 3),
                new ReviewQuestion("Photography", "communication", "Communication & Friendliness", 4),
                new ReviewQuestion("Photography", "professionalism", "Professional Demeanor", 5),
                new ReviewQuestion("Photography", "delivery_quality", "Final Album / Video Delivery Quality", 6),

                // VENUE
                new ReviewQuestion("Venue", "venue_quality", "Venue Ambiance & Architecture", 1),
                new ReviewQuestion("Venue", "cleanliness", "Cleanliness & Maintenance", 2),
                new ReviewQuestion("Venue", "facilities", "Facilities & Parking Space", 3),
                new ReviewQuestion("Venue", "staff_behavior", "Staff Behavior & Hospitality", 4),
                new ReviewQuestion("Venue", "availability", "Availability & Accessibility", 5),
                new ReviewQuestion("Venue", "value_for_money", "Value for Money", 6),

                // MUSIC / DJ
                new ReviewQuestion("Music/DJ", "music_selection", "Music Selection & Playlist Variety", 1),
                new ReviewQuestion("Music/DJ", "sound_quality", "Sound Clarity & Audio Equipment Quality", 2),
                new ReviewQuestion("Music/DJ", "timing", "Punctuality & Set Timing", 3),
                new ReviewQuestion("Music/DJ", "professionalism", "DJ Professionalism & Demeanor", 4),
                new ReviewQuestion("Music/DJ", "crowd_engagement", "Crowd Engagement & Dancefloor Energy", 5),

                // MAKEUP
                new ReviewQuestion("Makeup", "makeup_quality", "Makeup & Styling Quality", 1),
                new ReviewQuestion("Makeup", "professionalism", "Artist Professionalism", 2),
                new ReviewQuestion("Makeup", "timeliness", "Punctuality & Ready on Time", 3),
                new ReviewQuestion("Makeup", "product_quality", "Product & Cosmetic Brand Quality", 4),
                new ReviewQuestion("Makeup", "respectful_behavior", "Client Care & Respectful Behavior", 5),

                // GENERAL
                new ReviewQuestion("General", "service_quality", "Overall Service Quality", 1),
                new ReviewQuestion("General", "communication", "Prompt Communication", 2),
                new ReviewQuestion("General", "timeliness", "Punctuality & Timeliness", 3),
                new ReviewQuestion("General", "professionalism", "Professionalism", 4),
                new ReviewQuestion("General", "value_for_money", "Value for Money", 5),

                // VENDOR REVIEWING CUSTOMER
                new ReviewQuestion("Customer", "communication", "Client Communication", 1),
                new ReviewQuestion("Customer", "respectful_behavior", "Respectful & Polite Behavior", 2),
                new ReviewQuestion("Customer", "timeliness", "Event Schedule Adherence", 3),
                new ReviewQuestion("Customer", "cooperation", "Cooperation & Venue Access", 4),
                new ReviewQuestion("Customer", "booking_reliability", "Booking Reliability & Prompt Payment", 5),
                new ReviewQuestion("Customer", "overall_experience", "Overall Working Experience", 6)
        );

        questionRepository.saveAll(questions);
        logger.info("Seeded {} category-specific review questions.", questions.size());
    }

    private User initCustomer() {
        return userRepository.findByEmailIgnoreCase("customer@eventora.com").orElseGet(() -> {
            User user = new User("[DEMO] Ananya Sharma", "9876543210", "customer@eventora.com",
                    passwordEncoder.encode("Customer@123"), Role.CUSTOMER);
            user.setEmailVerified(true);
            return userRepository.save(user);
        });
    }

    private User initVendorDecorUser() {
        return userRepository.findByEmailIgnoreCase("vendor.decor@eventora.com").orElseGet(() -> {
            User user = new User("[DEMO] Rajesh Kumar", "9848012345", "vendor.decor@eventora.com",
                    passwordEncoder.encode("Vendor@123"), Role.VENDOR);
            user.setEmailVerified(true);
            return userRepository.save(user);
        });
    }

    private User initVendorPhotoUser() {
        return userRepository.findByEmailIgnoreCase("vendor.photo@eventora.com").orElseGet(() -> {
            User user = new User("[DEMO] Karthik Verma", "9848054321", "vendor.photo@eventora.com",
                    passwordEncoder.encode("Vendor@123"), Role.VENDOR);
            user.setEmailVerified(true);
            return userRepository.save(user);
        });
    }

    private User initVendorCateringUser() {
        return userRepository.findByEmailIgnoreCase("vendor.catering@eventora.com").orElseGet(() -> {
            User user = new User("[DEMO] Chef Sitaram", "9848098765", "vendor.catering@eventora.com",
                    passwordEncoder.encode("Vendor@123"), Role.VENDOR);
            user.setEmailVerified(true);
            return userRepository.save(user);
        });
    }

    private void initAdminUser() {
        if (!userRepository.existsByEmailIgnoreCase("admin@eventora.com")) {
            User admin = new User("[DEMO] Eventora Admin", "9999999999", "admin@eventora.com",
                    passwordEncoder.encode("Admin@123"), Role.ADMIN);
            admin.setEmailVerified(true);
            userRepository.save(admin);
        }
    }

    private void initVendorsAndCatalog(User decorUser, User photoUser, User cateringUser, User customer) {
        // 1. Dream Decor
        Vendor dreamDecor = new Vendor(
                "Dream Decor",
                "Rajesh Kumar",
                "vendor.decor@eventora.com",
                "9848012345",
                "Decoration",
                "Premier event decoration service specializing in stage decorations, luxury weddings, floral artistry, theme birthdays, and corporate events across coastal Andhra Pradesh.",
                "Visakhapatnam",
                "Visakhapatnam, Vizianagaram, Anakapalle",
                15000.0,
                "decorations/wedding/wedding.jpg"
        );
        dreamDecor.setUser(decorUser);
        dreamDecor.setRating(4.9);
        dreamDecor.setReviewCount(28);
        dreamDecor = vendorRepository.save(dreamDecor);

        // Services for Dream Decor
        ServiceEntity s1 = serviceRepository.save(new ServiceEntity(
                dreamDecor, "Decoration", "Stage & Mandap Decoration",
                "Customized stage backdrops, floral mandaps, lighting, and entrance arches for weddings and receptions.",
                25000.0, "Visakhapatnam", "decorations/wedding/royal.jpg"
        ));
        ServiceEntity s2 = serviceRepository.save(new ServiceEntity(
                dreamDecor, "Decoration", "Theme Birthday & Milestone Celebrations",
                "Vibrant balloon arches, customized cartoon or milestone themes, cake table backdrops, and interactive lights.",
                12000.0, "Visakhapatnam", "decorations/birthday/birthday.jpg"
        ));
        ServiceEntity s3 = serviceRepository.save(new ServiceEntity(
                dreamDecor, "Decoration", "Floral Artistry & Garland Styling",
                "Fresh seasonal flower backdrops, traditional jasmine/marigold setups, and elegant table centerpieces.",
                18000.0, "Visakhapatnam", "decorations/wedding/floral.jpg"
        ));

        // Design Packages for Dream Decor (using project decoration images!)
        DesignPackage dp1 = packageRepository.save(new DesignPackage(
                dreamDecor, s1, "Decoration", "Royal Wedding Stage", "Stage",
                "Grand royal stage with elegant flowers, luxury seating, chandeliers, and golden ambient spotlights.",
                35000.0, "decorations/wedding/royal.jpg"
        ));
        DesignPackage dp2 = packageRepository.save(new DesignPackage(
                dreamDecor, s3, "Decoration", "Floral Dream Backdrop", "Floral",
                "Exquisite natural rose and carnation backdrop with illuminated fairy lights and crystal pedestals.",
                28000.0, "decorations/wedding/floral.jpg"
        ));
        DesignPackage dp3 = packageRepository.save(new DesignPackage(
                dreamDecor, s1, "Decoration", "Traditional South Indian Mandap", "Traditional",
                "Authentic brass lamps, marigold hangings, banana stems, and royal temple bells for traditional ceremonies.",
                22000.0, "decorations/wedding/traditional.jpg"
        ));
        DesignPackage dp4 = packageRepository.save(new DesignPackage(
                dreamDecor, s1, "Decoration", "Minimalist Chic Reception", "Minimal",
                "Modern pastel hues, geometrical metallic arches, soft warm lighting, and subtle pampas grass.",
                16000.0, "decorations/wedding/minimal.jpg"
        ));
        DesignPackage dp5 = packageRepository.save(new DesignPackage(
                dreamDecor, s1, "Decoration", "Luxury Crystal Gala", "Luxury",
                "High-end crystal hangings, premium imported orchids, LED video walls, and red carpet walk-ins.",
                48000.0, "decorations/wedding/luxury.jpg"
        ));
        DesignPackage dp6 = packageRepository.save(new DesignPackage(
                dreamDecor, s1, "Decoration", "Romantic Candlelight Setting", "Romantic",
                "Dreamy wedding setting with candle pillars, soft lavender florals, and delicate sheer drapes.",
                20000.0, "decorations/wedding/romantic.jpg"
        ));
        DesignPackage dp7 = packageRepository.save(new DesignPackage(
                dreamDecor, s2, "Decoration", "Carnival Birthday Fiesta", "Birthday",
                "Fun-filled balloons, personalized neon name board, mascot cutouts, and festive photo booths.",
                14000.0, "decorations/birthday/birthday.jpg"
        ));
        DesignPackage dp8 = packageRepository.save(new DesignPackage(
                dreamDecor, s1, "Decoration", "Silver Jubilee Anniversary", "Anniversary",
                "Silver & white themed stage with memory photo wall, floral hearts, and ambient fairy lights.",
                18000.0, "decorations/anniversary/anniversary.jpg"
        ));

        // 2. Pixel Moments Photography
        Vendor pixelMoments = new Vendor(
                "Pixel Moments Photography",
                "Karthik Verma",
                "vendor.photo@eventora.com",
                "9848054321",
                "Photography",
                "Award-winning cinematic wedding and event photographers capturing genuine emotions and timeless candid memories.",
                "Visakhapatnam",
                "All Andhra Pradesh & Telangana",
                12000.0,
                "decorations/wedding/romantic.jpg"
        );
        pixelMoments.setUser(photoUser);
        pixelMoments.setRating(4.8);
        pixelMoments.setReviewCount(34);
        vendorRepository.save(pixelMoments);

        serviceRepository.save(new ServiceEntity(
                pixelMoments, "Photography", "Candid Wedding & Drone Coverage",
                "Two candid photographers, 4K video teaser, drone footage, and premium leather album.",
                35000.0, "All AP", "decorations/wedding/romantic.jpg"
        ));

        // 3. Royal Feast Caterers
        Vendor royalCaterers = new Vendor(
                "Royal Feast Caterers",
                "Chef Sitaram",
                "vendor.catering@eventora.com",
                "9848098765",
                "Catering",
                "Authentic royal multi-cuisine banquet catering with hygienic live counters, traditional sweets, and custom menus.",
                "Visakhapatnam",
                "Visakhapatnam City",
                550.0,
                "decorations/wedding/traditional.jpg"
        );
        royalCaterers.setUser(cateringUser);
        royalCaterers.setRating(4.7);
        royalCaterers.setReviewCount(19);
        vendorRepository.save(royalCaterers);

        // 4. Beat Masters DJ & Sound
        Vendor beatMasters = new Vendor(
                "Beat Masters DJ & Sound",
                "DJ Rohan",
                "rohan@beatmasters.com",
                "9848011223",
                "Music/DJ",
                "High-octane sound, intelligent lighting, bass subwoofers, and club DJs for sangeets, receptions, and college fests.",
                "Visakhapatnam",
                "Visakhapatnam & Coastal AP",
                8000.0,
                "decorations/college/college.jpg"
        );
        beatMasters.setRating(4.9);
        beatMasters.setReviewCount(15);
        vendorRepository.save(beatMasters);

        // 5. Grand Palace Convention
        Vendor grandPalace = new Vendor(
                "Grand Palace Convention",
                "Murali Krishna",
                "booking@grandpalace.com",
                "9848099887",
                "Venue",
                "Air-conditioned convention hall with seating for 1200 guests, lush green open lawns, and 300-car valet parking.",
                "Visakhapatnam",
                "MVP Colony, Visakhapatnam",
                45000.0,
                "decorations/corporate/corporate.jpg"
        );
        grandPalace.setRating(4.8);
        grandPalace.setReviewCount(22);
        vendorRepository.save(grandPalace);

        // 6. Glamour Touch Bridal Studio
        Vendor glamourTouch = new Vendor(
                "Glamour Touch Bridal Studio",
                "Priya Reddy",
                "priya@glamourtouch.com",
                "9848077665",
                "Makeup",
                "Certified HD and Airbrush bridal makeup artists using premium international luxury cosmetics.",
                "Visakhapatnam",
                "Visakhapatnam",
                7500.0,
                "decorations/engagement/engagement.jpg"
        );
        glamourTouch.setRating(4.9);
        glamourTouch.setReviewCount(17);
        vendorRepository.save(glamourTouch);

        // 4. Create sample bookings demonstrating full lifecycle
        // Booking A: CONFIRMED with Advance Paid
        Booking bookingA = new Booking();
        bookingA.setCustomer(customer);
        bookingA.setVendor(dreamDecor);
        bookingA.setService(s1);
        bookingA.setDesignPackage(dp1);
        bookingA.setEventType("Wedding");
        bookingA.setEventDate(LocalDate.now().plusDays(20));
        bookingA.setStartTime("10:00 AM");
        bookingA.setEndTime("03:00 PM");
        bookingA.setVenueName("S Convention Hall");
        bookingA.setVenueAddress("Beach Road, Visakhapatnam - 530002");
        bookingA.setGuestCount(450);
        bookingA.setSelectedPackageName(dp1.getName());
        bookingA.setCustomerRequirements("Pastel pink floral highlights on the stage pillars.");
        bookingA.setTotalPrice(35000.0);
        bookingA.setAdvanceAmount(17500.0);
        bookingA.setRemainingAmount(17500.0);
        bookingA.setStatus(BookingStatus.CONFIRMED);
        bookingA.setPaymentStatus(PaymentStatus.ADVANCE_PAID);
        bookingA.setEventNotes("[" + LocalDateTime.now().minusDays(2).format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] Booking request submitted.\n"
                + "[" + LocalDateTime.now().minusDays(1).format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] Vendor confirmed booking!\n"
                + "[" + LocalDateTime.now().minusHours(12).format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] 50% Advance Payment of ₹17500 paid! Ref: TXN_EVT_ADV_DEMO1");
        bookingA = bookingRepository.save(bookingA);

        paymentRepository.save(new Payment(bookingA, 17500.0, PaymentType.ADVANCE, "UPI", "TXN_EVT_ADV_DEMO1", null, "customer@okaxis"));

        // Booking B: COMPLETED with Full Payment and Reviews
        Booking bookingB = new Booking();
        bookingB.setCustomer(customer);
        bookingB.setVendor(dreamDecor);
        bookingB.setService(s3);
        bookingB.setDesignPackage(dp2);
        bookingB.setEventType("Engagement");
        bookingB.setEventDate(LocalDate.now().minusDays(5));
        bookingB.setStartTime("06:00 PM");
        bookingB.setEndTime("10:00 PM");
        bookingB.setVenueName("Novotel Ocean View Deck");
        bookingB.setVenueAddress("Varun Beach, Visakhapatnam");
        bookingB.setGuestCount(180);
        bookingB.setSelectedPackageName(dp2.getName());
        bookingB.setCustomerRequirements("Fresh floral fragrance and illuminated fairy lights.");
        bookingB.setTotalPrice(28000.0);
        bookingB.setAdvanceAmount(14000.0);
        bookingB.setRemainingAmount(14000.0);
        bookingB.setStatus(BookingStatus.COMPLETED);
        bookingB.setPaymentStatus(PaymentStatus.FULLY_PAID);
        bookingB.setCustomerReviewed(true);
        bookingB.setVendorReviewed(true);
        bookingB.setEventNotes("[" + LocalDateTime.now().minusDays(10).format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] Booking confirmed.\n"
                + "[" + LocalDateTime.now().minusDays(5).format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] Service completed at venue!\n"
                + "[" + LocalDateTime.now().minusDays(5).format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] Final 50% payment paid. Event completed.");
        bookingB = bookingRepository.save(bookingB);

        paymentRepository.save(new Payment(bookingB, 14000.0, PaymentType.ADVANCE, "CARD", "TXN_EVT_ADV_DEMO2", "4242", null));
        paymentRepository.save(new Payment(bookingB, 14000.0, PaymentType.FINAL, "CARD", "TXN_EVT_FIN_DEMO2", "4242", null));

        // Reviews for bookingB
        reviewRepository.save(new Review(
                bookingB, customer, dreamDecor, null,
                ReviewType.CUSTOMER_TO_VENDOR,
                5,
                "{\"design_quality\":5,\"timeliness\":5,\"expectation_match\":5,\"professionalism\":5}",
                "Absolutely breathtaking decoration! The fresh flowers and stage lighting looked even better than the photos. Highly recommended!"
        ));

        reviewRepository.save(new Review(
                bookingB, decorUser, null, customer,
                ReviewType.VENDOR_TO_CUSTOMER,
                5,
                "{\"communication\":5,\"respectful_behavior\":5,\"timeliness\":5,\"cooperation\":5}",
                "Ananya was a wonderful client to work with. Very clear requirements, cooperative on venue access, and prompt with payment."
        ));

        // Booking C: PENDING
        Booking bookingC = new Booking();
        bookingC.setCustomer(customer);
        bookingC.setVendor(pixelMoments);
        bookingC.setEventType("Birthday");
        bookingC.setEventDate(LocalDate.now().plusDays(15));
        bookingC.setStartTime("05:00 PM");
        bookingC.setEndTime("09:00 PM");
        bookingC.setVenueName("Radisson Blu Resort");
        bookingC.setVenueAddress("Rushikonda, Visakhapatnam");
        bookingC.setGuestCount(80);
        bookingC.setSelectedPackageName("Candid Party Photography");
        bookingC.setCustomerRequirements("Capture candid interactions of children and cake cutting.");
        bookingC.setTotalPrice(12000.0);
        bookingC.setAdvanceAmount(6000.0);
        bookingC.setRemainingAmount(6000.0);
        bookingC.setStatus(BookingStatus.PENDING);
        bookingC.setPaymentStatus(PaymentStatus.NOT_PAID);
        bookingC.setEventNotes("[" + LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] Booking request submitted. Waiting for vendor confirmation.");
        bookingRepository.save(bookingC);

        logger.info("Seeded initial vendors, packages, services, and demo bookings.");
    }
}
