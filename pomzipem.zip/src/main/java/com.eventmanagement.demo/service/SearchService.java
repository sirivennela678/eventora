package com.eventmanagement.demo.service;

import com.eventmanagement.demo.model.RecentSearch;
import com.eventmanagement.demo.model.User;
import com.eventmanagement.demo.repository.RecentSearchRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class SearchService {

    private final RecentSearchRepository recentSearchRepository;

    public SearchService(RecentSearchRepository recentSearchRepository) {
        this.recentSearchRepository = recentSearchRepository;
    }

    public List<String> getSuggestions(String context, String query) {
        String ctx = (context != null && !context.trim().isEmpty()) ? context.toUpperCase() : "HOME";
        List<String> pool;

        switch (ctx) {
            case "VENDORS":
                pool = Arrays.asList(
                        "Dream Decor",
                        "Pixel Moments Photography",
                        "Royal Feast Caterers",
                        "Beat Masters DJ & Sound",
                        "Visakhapatnam vendors",
                        "Decoration vendors",
                        "Catering services"
                );
                break;
            case "DECORATION":
            case "VENDOR_DETAIL":
                pool = Arrays.asList(
                        "Stage decoration",
                        "Floral decoration",
                        "Wedding theme",
                        "Birthday theme",
                        "Reception decoration",
                        "Traditional mandap",
                        "Minimalist stage",
                        "Luxury crystal backdrop"
                );
                break;
            case "CATERING":
                pool = Arrays.asList(
                        "Wedding buffet",
                        "Vegetarian menu",
                        "Non-vegetarian dinner",
                        "Live food counters",
                        "High tea & snacks"
                );
                break;
            case "PHOTOGRAPHY":
                pool = Arrays.asList(
                        "Candid wedding photography",
                        "Pre-wedding couple shoot",
                        "Cinematic wedding teaser",
                        "Drone aerial coverage",
                        "Traditional photography"
                );
                break;
            case "BOOKINGS":
                pool = Arrays.asList(
                        "Pending bookings",
                        "Confirmed events",
                        "Completed celebrations",
                        "Dream Decor",
                        "Pixel Moments"
                );
                break;
            case "SERVICES":
                pool = Arrays.asList(
                        "Stage decoration",
                        "Candid photography",
                        "Catering buffet",
                        "DJ sound setup",
                        "Bridal makeup",
                        "Convention venue"
                );
                break;
            case "HOME":
            default:
                pool = Arrays.asList(
                        "Wedding vendors",
                        "Birthday decoration",
                        "Catering buffet",
                        "Photography studios",
                        "Grand wedding venues",
                        "DJ and entertainment"
                );
                break;
        }

        if (query != null && !query.trim().isEmpty()) {
            String lower = query.trim().toLowerCase();
            List<String> matched = pool.stream()
                    .filter(s -> s.toLowerCase().contains(lower))
                    .collect(Collectors.toList());
            if (!matched.isEmpty()) {
                return matched.subList(0, Math.min(matched.size(), 5));
            }
        }

        return pool.subList(0, Math.min(pool.size(), 5));
    }

    @Transactional
    public void saveRecentSearch(User user, String sessionId, String query, String pageContext) {
        if (query == null || query.trim().isEmpty()) return;
        String cleanQuery = query.trim();
        String ctx = (pageContext != null && !pageContext.trim().isEmpty()) ? pageContext.toUpperCase() : "HOME";

        RecentSearch search = new RecentSearch(user, sessionId, cleanQuery, ctx);
        recentSearchRepository.save(search);
    }

    public List<String> getRecentSearches(User user, String sessionId, String pageContext) {
        List<RecentSearch> list;
        if (user != null) {
            if (pageContext != null && !pageContext.equalsIgnoreCase("ALL")) {
                list = recentSearchRepository.findTop8ByUserIdAndPageContextOrderByCreatedAtDesc(user.getId(), pageContext.toUpperCase());
            } else {
                list = recentSearchRepository.findTop8ByUserIdOrderByCreatedAtDesc(user.getId());
            }
        } else if (sessionId != null && !sessionId.isEmpty()) {
            list = recentSearchRepository.findTop8BySessionIdAndPageContextOrderByCreatedAtDesc(sessionId, pageContext != null ? pageContext.toUpperCase() : "HOME");
        } else {
            return Collections.emptyList();
        }

        // Distinct while preserving order
        Set<String> seen = new LinkedHashSet<>();
        for (RecentSearch rs : list) {
            seen.add(rs.getQuery());
            if (seen.size() >= 5) break;
        }
        return new ArrayList<>(seen);
    }

    @Transactional
    public void clearRecentSearches(User user, String sessionId) {
        if (user != null) {
            recentSearchRepository.deleteByUserId(user.getId());
        } else if (sessionId != null && !sessionId.isEmpty()) {
            recentSearchRepository.deleteBySessionId(sessionId);
        }
    }
}
