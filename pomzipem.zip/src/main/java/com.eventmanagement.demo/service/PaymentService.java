package com.eventmanagement.demo.service;

import com.eventmanagement.demo.dto.PaymentRequestDto;
import com.eventmanagement.demo.model.*;
import com.eventmanagement.demo.repository.BookingRepository;
import com.eventmanagement.demo.repository.PaymentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;
    private final BookingService bookingService;

    public PaymentService(PaymentRepository paymentRepository,
                          BookingRepository bookingRepository,
                          BookingService bookingService) {
        this.paymentRepository = paymentRepository;
        this.bookingRepository = bookingRepository;
        this.bookingService = bookingService;
    }

    @Transactional
    public Payment processPayment(PaymentRequestDto dto, User customer) {
        Booking booking = bookingService.getBookingDetails(dto.getBookingId(), customer);

        // Ownership check
        if (!booking.getCustomer().getId().equals(customer.getId())) {
            throw new SecurityException("Only the booking owner can make payments.");
        }

        PaymentType paymentType;
        try {
            paymentType = PaymentType.valueOf(dto.getPaymentType().toUpperCase());
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid payment type. Must be ADVANCE or FINAL.");
        }

        Double amountToPay;
        String prefix;

        if (paymentType == PaymentType.ADVANCE) {
            if (booking.getStatus() != BookingStatus.CONFIRMED) {
                throw new IllegalStateException("Advance payment can only be paid once the vendor has CONFIRMED the booking. Current status: " + booking.getStatus());
            }
            if (booking.getPaymentStatus() == PaymentStatus.ADVANCE_PAID || booking.getPaymentStatus() == PaymentStatus.FULLY_PAID) {
                throw new IllegalStateException("Advance payment of 50% has already been paid for this booking.");
            }
            amountToPay = booking.getAdvanceAmount();
            prefix = "TXN_EVT_ADV_";
        } else {
            // FINAL payment
            if (booking.getPaymentStatus() != PaymentStatus.FINAL_PAYMENT_PENDING) {
                throw new IllegalStateException("Remaining 50% payment can only be made after the vendor marks service completed at the event location.");
            }
            amountToPay = booking.getRemainingAmount();
            prefix = "TXN_EVT_FIN_";
        }

        // Validate payment method
        String method = dto.getPaymentMethod() != null ? dto.getPaymentMethod().toUpperCase() : "CARD";
        String cardLast4 = null;
        String upiId = null;

        if ("CARD".equals(method)) {
            String cardNum = dto.getCardNumber() != null ? dto.getCardNumber().replaceAll("\\s+", "") : "";
            if (cardNum.length() >= 4) {
                cardLast4 = cardNum.substring(cardNum.length() - 4);
            } else {
                cardLast4 = "4242";
            }
        } else if ("UPI".equals(method)) {
            upiId = dto.getUpiId() != null && !dto.getUpiId().trim().isEmpty() ? dto.getUpiId().trim() : "customer@upi";
        }

        // Generate unique transaction reference
        String txnRef = prefix + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        Payment payment = new Payment(
                booking, amountToPay, paymentType, method, txnRef, cardLast4, upiId
        );
        Payment savedPayment = paymentRepository.save(payment);

        // Update booking state
        if (paymentType == PaymentType.ADVANCE) {
            booking.setPaymentStatus(PaymentStatus.ADVANCE_PAID);
            String note = "\n[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] "
                    + "50% Advance Payment of ₹" + String.format("%.0f", amountToPay) + " successfully paid! Ref: " + txnRef;
            booking.setEventNotes(booking.getEventNotes() + note);
        } else {
            booking.setPaymentStatus(PaymentStatus.FULLY_PAID);
            booking.setStatus(BookingStatus.COMPLETED);
            String note = "\n[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] "
                    + "Remaining 50% Payment of ₹" + String.format("%.0f", amountToPay) + " paid! Booking fully paid & COMPLETED. Ref: " + txnRef;
            booking.setEventNotes(booking.getEventNotes() + note);
        }

        bookingRepository.save(booking);
        return savedPayment;
    }

    public List<Payment> getPaymentsForBooking(Long bookingId, User user) {
        // Validate user can access booking
        bookingService.getBookingDetails(bookingId, user);
        return paymentRepository.findByBookingIdOrderByCreatedAtDesc(bookingId);
    }
}
