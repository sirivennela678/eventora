package com.eventmanagement.demo.service;

import com.eventmanagement.demo.model.DesignPackage;
import com.eventmanagement.demo.model.ServiceEntity;
import com.eventmanagement.demo.model.User;
import com.eventmanagement.demo.model.Vendor;
import com.eventmanagement.demo.repository.DesignPackageRepository;
import com.eventmanagement.demo.repository.ServiceRepository;
import com.eventmanagement.demo.repository.VendorRepository;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class VendorService {

    private final VendorRepository vendorRepository;
    private final ServiceRepository serviceRepository;
    private final DesignPackageRepository packageRepository;

    public VendorService(VendorRepository vendorRepository,
                         ServiceRepository serviceRepository,
                         DesignPackageRepository packageRepository) {
        this.vendorRepository = vendorRepository;
        this.serviceRepository = serviceRepository;
        this.packageRepository = packageRepository;
    }

    public List<Vendor> getAllVendors() {
        return vendorRepository.findAll();
    }

    public Optional<Vendor> getVendorById(Long id) {
        return vendorRepository.findById(id);
    }

    public Optional<Vendor> getVendorByUser(User user) {
        return vendorRepository.findByUser(user);
    }

    public Optional<Vendor> getVendorByUserId(Long userId) {
        return vendorRepository.findByUserId(userId);
    }

    public List<Vendor> searchVendors(String query, String category, String location,
                                      Double minPrice, Double maxPrice, Double minRating,
                                      Boolean isAvailable, String sortBy) {

        String trimmedQuery = (query != null && !query.trim().isEmpty()) ? query.trim() : null;
        String trimmedCategory = (category != null && !category.trim().isEmpty() && !category.equalsIgnoreCase("ALL")) ? category.trim() : null;
        String trimmedLocation = (location != null && !location.trim().isEmpty()) ? location.trim() : null;

        List<Vendor> results = vendorRepository.searchVendors(
                trimmedQuery, trimmedCategory, trimmedLocation,
                minPrice, maxPrice, minRating, isAvailable
        );

        if (sortBy == null) {
            sortBy = "rating_desc";
        }

        switch (sortBy.toLowerCase()) {
            case "rating_desc":
                results.sort(Comparator.comparing(Vendor::getRating, Comparator.nullsLast(Comparator.reverseOrder())));
                break;
            case "price_asc":
                results.sort(Comparator.comparing(Vendor::getStartingPrice, Comparator.nullsLast(Comparator.naturalOrder())));
                break;
            case "price_desc":
                results.sort(Comparator.comparing(Vendor::getStartingPrice, Comparator.nullsLast(Comparator.reverseOrder())));
                break;
            case "reviews_desc":
                results.sort(Comparator.comparing(Vendor::getReviewCount, Comparator.nullsLast(Comparator.reverseOrder())));
                break;
            case "recent":
                results.sort(Comparator.comparing(Vendor::getCreatedAt, Comparator.nullsLast(Comparator.reverseOrder())));
                break;
            default:
                break;
        }

        return results;
    }

    public List<ServiceEntity> getServicesForVendor(Long vendorId) {
        return serviceRepository.findByVendorId(vendorId);
    }

    public List<DesignPackage> getPackagesForVendor(Long vendorId, String query, String category,
                                                    String theme, Double minPrice, Double maxPrice,
                                                    Boolean isAvailable, String sortBy) {

        String trimmedQuery = (query != null && !query.trim().isEmpty()) ? query.trim() : null;
        String trimmedCategory = (category != null && !category.trim().isEmpty() && !category.equalsIgnoreCase("ALL")) ? category.trim() : null;
        String trimmedTheme = (theme != null && !theme.trim().isEmpty() && !theme.equalsIgnoreCase("ALL")) ? theme.trim() : null;

        List<DesignPackage> packages = packageRepository.searchPackages(
                vendorId, trimmedQuery, trimmedCategory, trimmedTheme, minPrice, maxPrice, isAvailable
        );

        if (sortBy != null) {
            switch (sortBy.toLowerCase()) {
                case "price_asc":
                    packages.sort(Comparator.comparing(DesignPackage::getPrice, Comparator.nullsLast(Comparator.naturalOrder())));
                    break;
                case "price_desc":
                    packages.sort(Comparator.comparing(DesignPackage::getPrice, Comparator.nullsLast(Comparator.reverseOrder())));
                    break;
                case "name_asc":
                    packages.sort(Comparator.comparing(DesignPackage::getName, Comparator.nullsLast(Comparator.naturalOrder())));
                    break;
                default:
                    break;
            }
        }

        return packages;
    }

    public List<ServiceEntity> searchServices(Long vendorId, String query, String category,
                                              Double minPrice, Double maxPrice, String sortBy) {
        String trimmedQuery = (query != null && !query.trim().isEmpty()) ? query.trim() : null;
        String trimmedCategory = (category != null && !category.trim().isEmpty() && !category.equalsIgnoreCase("ALL")) ? category.trim() : null;

        List<ServiceEntity> services = serviceRepository.searchServices(
                vendorId, trimmedQuery, trimmedCategory, minPrice, maxPrice
        );

        if (sortBy != null) {
            switch (sortBy.toLowerCase()) {
                case "price_asc":
                    services.sort(Comparator.comparing(ServiceEntity::getPrice, Comparator.nullsLast(Comparator.naturalOrder())));
                    break;
                case "price_desc":
                    services.sort(Comparator.comparing(ServiceEntity::getPrice, Comparator.nullsLast(Comparator.reverseOrder())));
                    break;
                case "name_asc":
                    services.sort(Comparator.comparing(ServiceEntity::getName, Comparator.nullsLast(Comparator.naturalOrder())));
                    break;
                default:
                    break;
            }
        }

        return services;
    }

    public Vendor saveVendor(Vendor vendor) {
        return vendorRepository.save(vendor);
    }

    public ServiceEntity saveService(ServiceEntity service) {
        return serviceRepository.save(service);
    }

    public DesignPackage savePackage(DesignPackage designPackage) {
        return packageRepository.save(designPackage);
    }
}
