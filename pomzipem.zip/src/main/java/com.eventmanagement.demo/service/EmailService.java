package com.eventmanagement.demo.service;

import com.eventmanagement.demo.model.EmailVerificationToken;
import com.eventmanagement.demo.model.User;
import com.eventmanagement.demo.repository.EmailVerificationTokenRepository;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    private final EmailVerificationTokenRepository tokenRepository;

    @Autowired(required = false)
    private JavaMailSender mailSender;

    @Value("${spring.mail.username:}")
    private String mailUsername;

    @Value("${eventora.mail.from:noreply@eventora.com}")
    private String mailFrom;

    @Value("${server.port:8081}")
    private String serverPort;

    public EmailService(EmailVerificationTokenRepository tokenRepository) {
        this.tokenRepository = tokenRepository;
    }

    /**
     * Create verification token and 6-digit OTP, save to DB, and send via email / console log.
     */
    @Transactional
    public EmailVerificationToken createAndSendVerificationToken(User user) {
        // Generate random 6-digit OTP
        String otp = String.format("%06d", new SecureRandom().nextInt(1_000_000));
        String token = UUID.randomUUID().toString();

        // Expire in 30 minutes
        EmailVerificationToken verificationToken = new EmailVerificationToken(token, otp, user, 30);
        tokenRepository.save(verificationToken);

        String verifyUrl = "http://localhost:" + serverPort + "/verify-email.html?token=" + token + "&email=" + user.getEmail();

        logger.info("================================================================================");
        logger.info("[EVENTORA EMAIL VERIFICATION]");
        logger.info("Recipient: {} ({})", user.getName(), user.getEmail());
        logger.info("6-Digit Verification Code (OTP): {}", otp);
        logger.info("Direct Verification Link: {}", verifyUrl);
        logger.info("Valid for: 30 minutes");
        logger.info("================================================================================");

        // Attempt actual SMTP send if credentials provided
        if (mailSender != null && mailUsername != null && !mailUsername.trim().isEmpty() && !mailUsername.equals("your-email@gmail.com")) {
            try {
                MimeMessage message = mailSender.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
                helper.setFrom(mailFrom != null && !mailFrom.isEmpty() ? mailFrom : mailUsername, "Eventora");
                helper.setTo(user.getEmail());
                helper.setSubject("Verify Your Eventora Account - Code: " + otp);

                String htmlContent = "<div style=\"font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #eadff2; border-radius: 16px; background: #faf7ff;\">"
                        + "<div style=\"text-align: center; margin-bottom: 24px;\">"
                        + "<h1 style=\"color: #9b3f9d; margin: 0;\">Eventora</h1>"
                        + "<p style=\"color: #7d6b88; font-size: 14px;\">PLAN • BOOK • CELEBRATE</p>"
                        + "</div>"
                        + "<h2 style=\"color: #24152f;\">Welcome to Eventora, " + user.getName() + "!</h2>"
                        + "<p style=\"color: #49384f; line-height: 1.6;\">Thank you for registering with Eventora. To complete your registration and activate your account, please verify your email address using the 6-digit code below or click the verification link.</p>"
                        + "<div style=\"background: #fff; border: 2px dashed #c94f9f; border-radius: 12px; padding: 18px; text-align: center; margin: 24px 0;\">"
                        + "<p style=\"margin: 0; color: #7d6b88; font-size: 13px; font-weight: bold;\">YOUR 6-DIGIT VERIFICATION CODE</p>"
                        + "<h1 style=\"margin: 10px 0 0 0; color: #9b3f9d; font-size: 36px; letter-spacing: 6px;\">" + otp + "</h1>"
                        + "</div>"
                        + "<p style=\"text-align: center; margin: 24px 0;\">"
                        + "<a href=\"" + verifyUrl + "\" style=\"display: inline-block; background: linear-gradient(135deg, #c94f9f, #9b3f9d); color: #fff; text-decoration: none; padding: 12px 28px; border-radius: 25px; font-weight: bold; font-size: 15px;\">Verify Email Address →</a>"
                        + "</p>"
                        + "<p style=\"color: #8b7996; font-size: 12px; text-align: center;\">This code is valid for 30 minutes. If you did not create this account, please ignore this email.</p>"
                        + "</div>";

                helper.setText(htmlContent, true);
                mailSender.send(message);
                logger.info("Verification email successfully dispatched via SMTP to {}", user.getEmail());
            } catch (Exception e) {
                logger.warn("SMTP email dispatch failed: {}. Dev verification link and OTP remain active in console/response.", e.getMessage());
            }
        } else {
            logger.info("SMTP credentials not configured. Verification code {} generated in dev/simulation mode.", otp);
        }

        return verificationToken;
    }

    /**
     * Verify email by Token
     */
    @Transactional
    public Optional<User> verifyToken(String token) {
        return tokenRepository.findByTokenAndUsedFalse(token)
                .filter(t -> !t.isExpired())
                .map(t -> {
                    t.setUsed(true);
                    User user = t.getUser();
                    user.setEmailVerified(true);
                    tokenRepository.save(t);
                    return user;
                });
    }

    /**
     * Verify email by OTP
     */
    @Transactional
    public Optional<User> verifyOtp(String email, String otp) {
        return tokenRepository.findTopByUser_EmailIgnoreCaseAndOtpAndUsedFalseOrderByCreatedAtDesc(email.trim(), otp.trim())
                .filter(t -> !t.isExpired())
                .map(t -> {
                    t.setUsed(true);
                    User user = t.getUser();
                    user.setEmailVerified(true);
                    tokenRepository.save(t);
                    return user;
                });
    }
}
