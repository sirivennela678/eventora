package com.eventmanagement.demo.service;

import com.eventmanagement.demo.dto.BookingRequestDto;
import com.eventmanagement.demo.model.*;
import com.eventmanagement.demo.repository.BookingRepository;
import com.eventmanagement.demo.repository.DesignPackageRepository;
import com.eventmanagement.demo.repository.ServiceRepository;
import com.eventmanagement.demo.repository.VendorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final VendorRepository vendorRepository;
    private final ServiceRepository serviceRepository;
    private final DesignPackageRepository packageRepository;

    public BookingService(BookingRepository bookingRepository,
                          VendorRepository vendorRepository,
                          ServiceRepository serviceRepository,
                          DesignPackageRepository packageRepository) {
        this.bookingRepository = bookingRepository;
        this.vendorRepository = vendorRepository;
        this.serviceRepository = serviceRepository;
        this.packageRepository = packageRepository;
    }

    @Transactional
    public Booking createBooking(BookingRequestDto dto, User customer) {
        if (customer == null) {
            throw new IllegalArgumentException("User must be logged in to create a booking.");
        }

        Vendor vendor = vendorRepository.findById(dto.getVendorId())
                .orElseThrow(() -> new IllegalArgumentException("Selected vendor does not exist."));

        ServiceEntity service = null;
        if (dto.getServiceId() != null) {
            service = serviceRepository.findById(dto.getServiceId()).orElse(null);
        }

        DesignPackage designPackage = null;
        if (dto.getDesignPackageId() != null) {
            designPackage = packageRepository.findById(dto.getDesignPackageId()).orElse(null);
        }

        Double totalPrice = dto.getTotalPrice();
        if (totalPrice == null || totalPrice <= 0) {
            if (designPackage != null && designPackage.getPrice() != null) {
                totalPrice = designPackage.getPrice();
            } else if (service != null && service.getPrice() != null) {
                totalPrice = service.getPrice();
            } else if (vendor.getStartingPrice() != null) {
                totalPrice = vendor.getStartingPrice();
            } else {
                totalPrice = 10000.0;
            }
        }

        Double advanceAmount = Math.round(totalPrice * 0.5 * 100.0) / 100.0;
        Double remainingAmount = Math.round((totalPrice - advanceAmount) * 100.0) / 100.0;

        Booking booking = new Booking();
        booking.setCustomer(customer);
        booking.setVendor(vendor);
        booking.setService(service);
        booking.setDesignPackage(designPackage);
        booking.setEventType(dto.getEventType());
        booking.setEventDate(dto.getEventDate());
        booking.setStartTime(dto.getStartTime());
        booking.setEndTime(dto.getEndTime());
        booking.setVenueName(dto.getVenueName());
        booking.setVenueAddress(dto.getVenueAddress());
        booking.setGuestCount(dto.getGuestCount());
        booking.setSelectedPackageName(dto.getSelectedPackageName() != null ? dto.getSelectedPackageName() : (designPackage != null ? designPackage.getName() : null));
        booking.setCustomerRequirements(dto.getCustomerRequirements());
        booking.setTotalPrice(totalPrice);
        booking.setAdvanceAmount(advanceAmount);
        booking.setRemainingAmount(remainingAmount);
        booking.setStatus(BookingStatus.PENDING);
        booking.setPaymentStatus(PaymentStatus.NOT_PAID);

        String initialNote = "[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] "
                + "Booking request submitted by " + customer.getName() + " (Status: PENDING)";
        if (dto.getNotes() != null && !dto.getNotes().trim().isEmpty()) {
            initialNote += "\nNote: " + dto.getNotes().trim();
        }
        booking.setEventNotes(initialNote);

        return bookingRepository.save(booking);
    }

    public List<Booking> getCustomerBookings(User customer, BookingStatus status,
                                            LocalDate startDate, LocalDate endDate,
                                            String query, String sortBy) {
        String trimmedQuery = (query != null && !query.trim().isEmpty()) ? query.trim() : null;
        List<Booking> bookings = bookingRepository.searchCustomerBookings(
                customer.getId(), status, startDate, endDate, trimmedQuery
        );

        applyBookingSorting(bookings, sortBy);
        return bookings;
    }

    public List<Booking> getVendorBookings(Vendor vendor, BookingStatus status,
                                          LocalDate startDate, LocalDate endDate,
                                          String query, String sortBy) {
        String trimmedQuery = (query != null && !query.trim().isEmpty()) ? query.trim() : null;
        List<Booking> bookings = bookingRepository.searchVendorBookings(
                vendor.getId(), status, startDate, endDate, trimmedQuery
        );

        applyBookingSorting(bookings, sortBy);
        return bookings;
    }

    private void applyBookingSorting(List<Booking> bookings, String sortBy) {
        if (sortBy == null) sortBy = "newest";
        switch (sortBy.toLowerCase()) {
            case "newest":
                bookings.sort(Comparator.comparing(Booking::getCreatedAt, Comparator.nullsLast(Comparator.reverseOrder())));
                break;
            case "oldest":
                bookings.sort(Comparator.comparing(Booking::getCreatedAt, Comparator.nullsLast(Comparator.naturalOrder())));
                break;
            case "event_date":
                bookings.sort(Comparator.comparing(Booking::getEventDate, Comparator.nullsLast(Comparator.naturalOrder())));
                break;
            case "status":
                bookings.sort(Comparator.comparing(b -> b.getStatus().name()));
                break;
            default:
                bookings.sort(Comparator.comparing(Booking::getCreatedAt, Comparator.nullsLast(Comparator.reverseOrder())));
                break;
        }
    }

    public Booking getBookingDetails(Long bookingId, User currentUser) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found."));

        if (!canUserAccessBooking(booking, currentUser)) {
            throw new SecurityException("You do not have permission to view this booking.");
        }

        return booking;
    }

    public boolean canUserAccessBooking(Booking booking, User user) {
        if (user == null) return false;
        if (user.getRole() == Role.ADMIN) return true;
        if (booking.getCustomer().getId().equals(user.getId())) return true;
        if (booking.getVendor().getUser() != null && booking.getVendor().getUser().getId().equals(user.getId())) return true;
        return false;
    }

    @Transactional
    public Booking confirmBookingByVendor(Long bookingId, User vendorUser) {
        Booking booking = getBookingDetails(bookingId, vendorUser);

        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new IllegalStateException("Only PENDING bookings can be confirmed. Current status: " + booking.getStatus());
        }

        booking.setStatus(BookingStatus.CONFIRMED);
        booking.setPaymentStatus(PaymentStatus.ADVANCE_PENDING);

        String note = "\n[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] "
                + "Vendor confirmed booking! 50% Advance Payment (₹" + String.format("%.0f", booking.getAdvanceAmount()) + ") is now requested.";
        booking.setEventNotes(booking.getEventNotes() + note);

        return bookingRepository.save(booking);
    }

    @Transactional
    public Booking cancelBooking(Long bookingId, User user, String reason) {
        Booking booking = getBookingDetails(bookingId, user);

        if (booking.getStatus() == BookingStatus.COMPLETED) {
            throw new IllegalStateException("Completed bookings cannot be cancelled.");
        }

        booking.setStatus(BookingStatus.CANCELLED);
        String cancelBy = (user.getRole() == Role.VENDOR || (booking.getVendor().getUser() != null && booking.getVendor().getUser().getId().equals(user.getId())))
                ? "Vendor (" + booking.getVendor().getBusinessName() + ")"
                : "Customer (" + user.getName() + ")";

        String note = "\n[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] "
                + "Booking cancelled by " + cancelBy + ". Reason: " + (reason != null ? reason : "No reason provided.");
        booking.setEventNotes(booking.getEventNotes() + note);

        return bookingRepository.save(booking);
    }

    @Transactional
    public Booking markServiceCompletedByVendor(Long bookingId, User vendorUser) {
        Booking booking = getBookingDetails(bookingId, vendorUser);

        if (booking.getStatus() != BookingStatus.CONFIRMED) {
            throw new IllegalStateException("Only CONFIRMED bookings can be marked as completed. Current status: " + booking.getStatus());
        }

        if (booking.getPaymentStatus() != PaymentStatus.ADVANCE_PAID) {
            throw new IllegalStateException("Advance payment of 50% must be paid before service can be completed.");
        }

        booking.setPaymentStatus(PaymentStatus.FINAL_PAYMENT_PENDING);

        String note = "\n[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] "
                + "Vendor completed event service at venue! Remaining 50% payment (₹" + String.format("%.0f", booking.getRemainingAmount()) + ") is now pending.";
        booking.setEventNotes(booking.getEventNotes() + note);

        return bookingRepository.save(booking);
    }

    @Transactional
    public Booking addCommunicationNote(Long bookingId, User user, String message) {
        Booking booking = getBookingDetails(bookingId, user);

        String sender = user.getName() + " (" + user.getRole() + ")";
        String note = "\n[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] "
                + sender + ": " + message.trim();

        booking.setEventNotes(booking.getEventNotes() + note);
        return bookingRepository.save(booking);
    }
}
