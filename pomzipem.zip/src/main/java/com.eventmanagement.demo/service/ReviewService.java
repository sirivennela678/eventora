package com.eventmanagement.demo.service;

import com.eventmanagement.demo.dto.ReviewRequestDto;
import com.eventmanagement.demo.model.*;
import com.eventmanagement.demo.repository.BookingRepository;
import com.eventmanagement.demo.repository.ReviewQuestionRepository;
import com.eventmanagement.demo.repository.ReviewRepository;
import com.eventmanagement.demo.repository.VendorRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final ReviewQuestionRepository questionRepository;
    private final BookingRepository bookingRepository;
    private final VendorRepository vendorRepository;
    private final BookingService bookingService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public ReviewService(ReviewRepository reviewRepository,
                         ReviewQuestionRepository questionRepository,
                         BookingRepository bookingRepository,
                         VendorRepository vendorRepository,
                         BookingService bookingService) {
        this.reviewRepository = reviewRepository;
        this.questionRepository = questionRepository;
        this.bookingRepository = bookingRepository;
        this.vendorRepository = vendorRepository;
        this.bookingService = bookingService;
    }

    public List<ReviewQuestion> getQuestionsByCategory(String category) {
        String cat = (category != null && !category.trim().isEmpty()) ? category.trim() : "General";
        List<ReviewQuestion> questions = questionRepository.findByCategoryIgnoreCaseOrderByDisplayOrderAsc(cat);
        if (questions.isEmpty()) {
            questions = questionRepository.findByCategoryIgnoreCaseOrderByDisplayOrderAsc("General");
        }
        return questions;
    }

    @Transactional
    public Review submitCustomerReview(ReviewRequestDto dto, User customer) {
        Booking booking = bookingService.getBookingDetails(dto.getBookingId(), customer);

        if (booking.getStatus() != BookingStatus.COMPLETED) {
            throw new IllegalStateException("Reviews are only allowed after the booking is COMPLETED. Current status: " + booking.getStatus());
        }

        if (!booking.getCustomer().getId().equals(customer.getId())) {
            throw new SecurityException("Only the customer who made this booking can submit a customer review.");
        }

        if (reviewRepository.existsByBookingIdAndReviewType(booking.getId(), ReviewType.CUSTOMER_TO_VENDOR)) {
            throw new IllegalStateException("You have already reviewed this completed booking.");
        }

        String scoresJson = null;
        if (dto.getCategoryScores() != null && !dto.getCategoryScores().isEmpty()) {
            try {
                scoresJson = objectMapper.writeValueAsString(dto.getCategoryScores());
            } catch (Exception e) {
                scoresJson = "{}";
            }
        }

        Vendor vendor = booking.getVendor();
        Review review = new Review(
                booking, customer, vendor, null,
                ReviewType.CUSTOMER_TO_VENDOR,
                dto.getRating(), scoresJson, dto.getComment()
        );
        Review savedReview = reviewRepository.save(review);

        // Update vendor rating & count
        List<Review> allVendorReviews = reviewRepository.findByRevieweeVendorIdOrderByCreatedAtDesc(vendor.getId());
        double avgRating = allVendorReviews.stream()
                .mapToInt(Review::getRating)
                .average()
                .orElse(dto.getRating());

        vendor.setRating(Math.round(avgRating * 10.0) / 10.0);
        vendor.setReviewCount(allVendorReviews.size());
        vendorRepository.save(vendor);

        booking.setCustomerReviewed(true);
        String note = "\n[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] "
                + "Customer " + customer.getName() + " submitted a " + dto.getRating() + "-star review for vendor.";
        booking.setEventNotes(booking.getEventNotes() + note);
        bookingRepository.save(booking);

        return savedReview;
    }

    @Transactional
    public Review submitVendorReview(ReviewRequestDto dto, User vendorUser) {
        Booking booking = bookingService.getBookingDetails(dto.getBookingId(), vendorUser);

        if (booking.getStatus() != BookingStatus.COMPLETED) {
            throw new IllegalStateException("Reviews are only allowed after the booking is COMPLETED. Current status: " + booking.getStatus());
        }

        if (booking.getVendor().getUser() == null || !booking.getVendor().getUser().getId().equals(vendorUser.getId())) {
            if (vendorUser.getRole() != Role.VENDOR && vendorUser.getRole() != Role.ADMIN) {
                throw new SecurityException("Only the designated vendor can review the customer.");
            }
        }

        if (reviewRepository.existsByBookingIdAndReviewType(booking.getId(), ReviewType.VENDOR_TO_CUSTOMER)) {
            throw new IllegalStateException("Vendor review has already been submitted for this booking.");
        }

        String scoresJson = null;
        if (dto.getCategoryScores() != null && !dto.getCategoryScores().isEmpty()) {
            try {
                scoresJson = objectMapper.writeValueAsString(dto.getCategoryScores());
            } catch (Exception e) {
                scoresJson = "{}";
            }
        }

        User customer = booking.getCustomer();
        Review review = new Review(
                booking, vendorUser, null, customer,
                ReviewType.VENDOR_TO_CUSTOMER,
                dto.getRating(), scoresJson, dto.getComment()
        );
        Review savedReview = reviewRepository.save(review);

        booking.setVendorReviewed(true);
        String note = "\n[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) + "] "
                + "Vendor submitted a " + dto.getRating() + "-star review for customer " + customer.getName() + ".";
        booking.setEventNotes(booking.getEventNotes() + note);
        bookingRepository.save(booking);

        return savedReview;
    }

    public List<Review> getReviewsForVendor(Long vendorId) {
        return reviewRepository.findByRevieweeVendorIdOrderByCreatedAtDesc(vendorId);
    }

    public List<Review> getReviewsForCustomer(Long customerId) {
        return reviewRepository.findByRevieweeCustomerIdOrderByCreatedAtDesc(customerId);
    }
}
