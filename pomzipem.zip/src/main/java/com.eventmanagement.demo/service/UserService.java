package com.eventmanagement.demo.service;

import com.eventmanagement.demo.dto.RegisterRequest;
import com.eventmanagement.demo.dto.UserProfileDto;
import com.eventmanagement.demo.model.EmailVerificationToken;
import com.eventmanagement.demo.model.Role;
import com.eventmanagement.demo.model.User;
import com.eventmanagement.demo.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class UserService {

    public static final String SESSION_USER_KEY = "CURRENT_USER";
    public static final String SESSION_USER_ID = "CURRENT_USER_ID";
    public static final String SESSION_USER_ROLE = "CURRENT_USER_ROLE";

    private final UserRepository userRepository;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;

    public UserService(
            UserRepository userRepository,
            EmailService emailService,
            PasswordEncoder passwordEncoder) {

        this.userRepository = userRepository;
        this.emailService = emailService;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public User register(RegisterRequest request) {

        String name = request.getName() != null
                ? request.getName().trim()
                : "";

        if (name.length() < 2) {
            throw new IllegalArgumentException(
                    "Please enter your full name.");
        }

        String phone = request.getPhone() != null
                ? request.getPhone().trim()
                : "";

        if (!phone.matches("^\\d{10}$")) {
            throw new IllegalArgumentException(
                    "Phone number must contain exactly 10 digits.");
        }

        String email = request.getEmail() != null
                ? request.getEmail().trim().toLowerCase()
                : "";

        if (!email.matches(
                "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {

            throw new IllegalArgumentException(
                    "Please enter a valid email address.");
        }

        if (request.getPassword() == null ||
                request.getPassword().length() < 6) {

            throw new IllegalArgumentException(
                    "Password must be at least 6 characters long.");
        }

        if (request.getConfirmPassword() == null ||
                !request.getPassword()
                        .equals(request.getConfirmPassword())) {

            throw new IllegalArgumentException(
                    "Passwords do not match.");
        }

        if (userRepository.existsByEmailIgnoreCase(email)) {
            throw new IllegalArgumentException(
                    "An account with this email address already exists.");
        }

        Role role = Role.CUSTOMER;

        if (request.getRole() != null &&
                request.getRole().equalsIgnoreCase("VENDOR")) {

            role = Role.VENDOR;
        }

        User user = new User();

        user.setName(name);
        user.setPhone(phone);
        user.setEmail(email);

        // Store password securely using BCrypt.
        user.setPassword(
                passwordEncoder.encode(request.getPassword()));

        user.setRole(role);

        // NO OTP / EMAIL VERIFICATION REQUIRED.
        user.setEmailVerified(true);

        return userRepository.save(user);
    }

    /*
     * Kept so existing OTP-related classes don't break.
     * Normal registration/login no longer requires OTP.
     */
    @Transactional
    public User verifyEmailByToken(String token) {

        return emailService.verifyToken(token)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Invalid or expired verification token."));
    }

    @Transactional
    public User verifyEmailByOtp(String email, String otp) {

        return emailService.verifyOtp(email, otp)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Invalid or expired verification code."));
    }

    /*
     * Kept for compatibility with the existing resend-OTP endpoint.
     * It is no longer required for normal registration/login.
     */
    @Transactional
    public EmailVerificationToken resendVerification(String email) {

        User user = userRepository
                .findByEmailIgnoreCase(
                        email.trim().toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException(
                        "No account found with this email address."));

        return emailService.createAndSendVerificationToken(user);
    }

    @Transactional
    public User login(
            String email,
            String password,
            HttpSession session) {

        String normalizedEmail = email != null
                ? email.trim().toLowerCase()
                : "";

        User user = userRepository
                .findByEmailIgnoreCase(normalizedEmail)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Invalid email or password."));

        boolean passwordMatches = passwordEncoder.matches(
                password,
                user.getPassword());

        /*
         * Legacy password support.
         * If an old account has a plain-text password,
         * upgrade it to BCrypt after successful login.
         */
        if (!passwordMatches &&
                user.getPassword().equals(password)) {

            user.setPassword(
                    passwordEncoder.encode(password));

            userRepository.save(user);

            passwordMatches = true;
        }

        if (!passwordMatches) {
            throw new IllegalArgumentException(
                    "Invalid email or password.");
        }

        /*
         * IMPORTANT:
         * There is NO email verification check here.
         * A registered user can log in immediately.
         */

        user.setEmailVerified(true);

        userRepository.save(user);

        if (session != null) {

            session.setAttribute(
                    SESSION_USER_KEY,
                    UserProfileDto.fromEntity(user));

            session.setAttribute(
                    SESSION_USER_ID,
                    user.getId());

            session.setAttribute(
                    SESSION_USER_ROLE,
                    user.getRole().name());

            session.setAttribute(
                    "userName",
                    user.getName());

            session.setAttribute(
                    "userEmail",
                    user.getEmail());
        }

        return user;
    }

    public void logout(HttpSession session) {

        if (session != null) {

            session.removeAttribute(SESSION_USER_KEY);
            session.removeAttribute(SESSION_USER_ID);
            session.removeAttribute(SESSION_USER_ROLE);
            session.removeAttribute("userName");
            session.removeAttribute("userEmail");

            session.invalidate();
        }
    }

    public User getCurrentAuthenticatedUser(
            HttpSession session) {

        if (session == null) {
            return null;
        }

        Long userId = (Long) session.getAttribute(
                SESSION_USER_ID);

        if (userId == null) {
            return null;
        }

        return userRepository
                .findById(userId)
                .orElse(null);
    }

    @Transactional
    public User updateProfile(
            Long userId,
            String name,
            String phone) {

        User user = userRepository
                .findById(userId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "User not found"));

        if (name != null &&
                name.trim().length() >= 2) {

            user.setName(name.trim());
        }

        if (phone != null &&
                phone.trim().matches("^\\d{10}$")) {

            user.setPhone(phone.trim());
        }

        return userRepository.save(user);
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public Optional<User> findByEmail(String email) {

        return userRepository.findByEmailIgnoreCase(
                email.trim().toLowerCase());
    }
}