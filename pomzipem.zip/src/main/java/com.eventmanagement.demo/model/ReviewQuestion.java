package com.eventmanagement.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "review_questions")
public class ReviewQuestion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String category;

    @Column(name = "question_key", nullable = false, length = 100)
    private String questionKey;

    @Column(name = "question_label", nullable = false)
    private String questionLabel;

    @Column(name = "display_order", nullable = false)
    private Integer displayOrder = 0;

    public ReviewQuestion() {
    }

    public ReviewQuestion(String category, String questionKey, String questionLabel, Integer displayOrder) {
        this.category = category;
        this.questionKey = questionKey;
        this.questionLabel = questionLabel;
        this.displayOrder = displayOrder;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getQuestionKey() {
        return questionKey;
    }

    public void setQuestionKey(String questionKey) {
        this.questionKey = questionKey;
    }

    public String getQuestionLabel() {
        return questionLabel;
    }

    public void setQuestionLabel(String questionLabel) {
        this.questionLabel = questionLabel;
    }

    public Integer getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Integer displayOrder) {
        this.displayOrder = displayOrder;
    }
}
