package com.eventmanagement.demo.model;

public enum Role {
    CUSTOMER,
    VENDOR,
    ADMIN
}
