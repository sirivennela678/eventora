package com.eventmanagement.demo.model;

public enum ReviewType {
    CUSTOMER_TO_VENDOR,
    VENDOR_TO_CUSTOMER
}
