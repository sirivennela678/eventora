package com.eventmanagement.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "reviews")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_id", nullable = false)
    private Booking booking;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "reviewer_id", nullable = false)
    private User reviewer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_id")
    private Vendor revieweeVendor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id")
    private User revieweeCustomer;

    @Enumerated(EnumType.STRING)
    @Column(name = "review_type", nullable = false, length = 30)
    private ReviewType reviewType;

    @Column(nullable = false)
    private Integer rating;

    @Column(name = "category_scores_json", columnDefinition = "TEXT")
    private String categoryScoresJson;

    @Column(columnDefinition = "TEXT")
    private String comment;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public Review() {
    }

    public Review(Booking booking, User reviewer, Vendor revieweeVendor, User revieweeCustomer,
                  ReviewType reviewType, Integer rating, String categoryScoresJson, String comment) {
        this.booking = booking;
        this.reviewer = reviewer;
        this.revieweeVendor = revieweeVendor;
        this.revieweeCustomer = revieweeCustomer;
        this.reviewType = reviewType;
        this.rating = rating;
        this.categoryScoresJson = categoryScoresJson;
        this.comment = comment;
        this.createdAt = LocalDateTime.now();
    }

    @PrePersist
    protected void onCreate() {
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public User getReviewer() {
        return reviewer;
    }

    public void setReviewer(User reviewer) {
        this.reviewer = reviewer;
    }

    public Vendor getRevieweeVendor() {
        return revieweeVendor;
    }

    public void setRevieweeVendor(Vendor revieweeVendor) {
        this.revieweeVendor = revieweeVendor;
    }

    public User getRevieweeCustomer() {
        return revieweeCustomer;
    }

    public void setRevieweeCustomer(User revieweeCustomer) {
        this.revieweeCustomer = revieweeCustomer;
    }

    public ReviewType getReviewType() {
        return reviewType;
    }

    public void setReviewType(ReviewType reviewType) {
        this.reviewType = reviewType;
    }

    public Integer getRating() {
        return rating;
    }

    public Integer getOverallRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getCategoryScoresJson() {
        return categoryScoresJson;
    }

    public void setCategoryScoresJson(String categoryScoresJson) {
        this.categoryScoresJson = categoryScoresJson;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
