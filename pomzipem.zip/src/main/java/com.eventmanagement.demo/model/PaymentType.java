package com.eventmanagement.demo.model;

public enum PaymentType {
    ADVANCE,
    FINAL
}
