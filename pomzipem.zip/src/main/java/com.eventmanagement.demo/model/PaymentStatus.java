package com.eventmanagement.demo.model;

public enum PaymentStatus {
    NOT_PAID,
    ADVANCE_PENDING,
    ADVANCE_PAID,
    FINAL_PAYMENT_PENDING,
    FULLY_PAID,
    REFUNDED
}
