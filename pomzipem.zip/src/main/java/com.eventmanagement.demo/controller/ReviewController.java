package com.eventmanagement.demo.controller;

import com.eventmanagement.demo.dto.ApiResponse;
import com.eventmanagement.demo.dto.ReviewRequestDto;
import com.eventmanagement.demo.model.Review;
import com.eventmanagement.demo.model.ReviewQuestion;
import com.eventmanagement.demo.model.User;
import com.eventmanagement.demo.service.ReviewService;
import com.eventmanagement.demo.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    private final ReviewService reviewService;
    private final UserService userService;

    public ReviewController(ReviewService reviewService, UserService userService) {
        this.reviewService = reviewService;
        this.userService = userService;
    }

    @GetMapping("/questions")
    public ResponseEntity<ApiResponse<List<ReviewQuestion>>> getQuestions(
            @RequestParam(required = false, defaultValue = "General") String category) {
        List<ReviewQuestion> questions = reviewService.getQuestionsByCategory(category);
        return ResponseEntity.ok(ApiResponse.ok("Review questions retrieved", questions));
    }

    @PostMapping("/customer")
    public ResponseEntity<ApiResponse<Review>> submitCustomerReview(
            @Valid @RequestBody ReviewRequestDto dto,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to submit a review."));
        }

        Review review = reviewService.submitCustomerReview(dto, currentUser);
        return ResponseEntity.ok(ApiResponse.ok("Thank you! Your review for the vendor has been submitted.", review));
    }

    @PostMapping("/vendor")
    public ResponseEntity<ApiResponse<Review>> submitVendorReview(
            @Valid @RequestBody ReviewRequestDto dto,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to submit a review."));
        }

        Review review = reviewService.submitVendorReview(dto, currentUser);
        return ResponseEntity.ok(ApiResponse.ok("Thank you! Your feedback for the customer has been recorded.", review));
    }

    @GetMapping("/vendor/{vendorId}")
    public ResponseEntity<ApiResponse<List<Review>>> getVendorReviews(@PathVariable Long vendorId) {
        List<Review> reviews = reviewService.getReviewsForVendor(vendorId);
        return ResponseEntity.ok(ApiResponse.ok("Vendor reviews retrieved", reviews));
    }
}
