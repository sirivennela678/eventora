package com.eventmanagement.demo.controller;

import com.eventmanagement.demo.dto.ApiResponse;
import com.eventmanagement.demo.model.DesignPackage;
import com.eventmanagement.demo.model.Review;
import com.eventmanagement.demo.model.ServiceEntity;
import com.eventmanagement.demo.model.Vendor;
import com.eventmanagement.demo.service.ReviewService;
import com.eventmanagement.demo.service.VendorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
public class VendorController {

    private final VendorService vendorService;
    private final ReviewService reviewService;

    public VendorController(VendorService vendorService, ReviewService reviewService) {
        this.vendorService = vendorService;
        this.reviewService = reviewService;
    }

    @GetMapping("/vendors")
    public ResponseEntity<ApiResponse<List<Vendor>>> getVendors(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) Double minRating,
            @RequestParam(required = false) Boolean isAvailable,
            @RequestParam(required = false, defaultValue = "rating_desc") String sortBy,
            @RequestParam(required = false) String sort) {

        String effectiveQuery = (query != null && !query.trim().isEmpty()) ? query : search;
        String effectiveSort = (sort != null && !sort.trim().isEmpty()) ? sort : sortBy;

        List<Vendor> vendors = vendorService.searchVendors(
                effectiveQuery, category, location, minPrice, maxPrice, minRating, isAvailable, effectiveSort
        );
        return ResponseEntity.ok(ApiResponse.ok("Vendors retrieved", vendors));
    }

    @GetMapping("/vendors/{id}")
    public ResponseEntity<ApiResponse<Vendor>> getVendorById(@PathVariable Long id) {
        return vendorService.getVendorById(id)
                .map(v -> ResponseEntity.ok(ApiResponse.ok("Vendor found", v)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/vendors/{id}/services")
    public ResponseEntity<ApiResponse<List<ServiceEntity>>> getVendorServices(@PathVariable Long id) {
        List<ServiceEntity> services = vendorService.getServicesForVendor(id);
        return ResponseEntity.ok(ApiResponse.ok("Services retrieved", services));
    }

    @GetMapping("/vendors/{id}/packages")
    public ResponseEntity<ApiResponse<List<DesignPackage>>> getVendorPackages(
            @PathVariable Long id,
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String theme,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) Boolean isAvailable,
            @RequestParam(required = false) String sortBy) {

        List<DesignPackage> packages = vendorService.getPackagesForVendor(
                id, query, category, theme, minPrice, maxPrice, isAvailable, sortBy
        );
        return ResponseEntity.ok(ApiResponse.ok("Packages retrieved", packages));
    }

    @GetMapping("/vendors/{id}/reviews")
    public ResponseEntity<ApiResponse<List<Review>>> getVendorReviews(@PathVariable Long id) {
        List<Review> reviews = reviewService.getReviewsForVendor(id);
        return ResponseEntity.ok(ApiResponse.ok("Reviews retrieved", reviews));
    }

    @GetMapping("/services")
    public ResponseEntity<ApiResponse<List<ServiceEntity>>> getAllServices(
            @RequestParam(required = false) Long vendorId,
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) String sortBy) {

        List<ServiceEntity> services = vendorService.searchServices(vendorId, query, category, minPrice, maxPrice, sortBy);
        return ResponseEntity.ok(ApiResponse.ok("Services retrieved", services));
    }

    @GetMapping("/categories")
    public ResponseEntity<ApiResponse<List<Map<String, String>>>> getCategories() {
        List<Map<String, String>> categories = Arrays.asList(
                Map.of("id", "Decoration", "name", "Decoration", "icon", "💐", "desc", "Themes, florals, stages & entrance decor"),
                Map.of("id", "Photography", "name", "Photography", "icon", "📸", "desc", "Candid shots, pre-wedding & cinematic videos"),
                Map.of("id", "Catering", "name", "Catering", "icon", "🍽️", "desc", "Customized veg & non-veg feasts"),
                Map.of("id", "Music/DJ", "name", "Music & DJ", "icon", "🎧", "desc", "Live DJs, sound systems & dance floors"),
                Map.of("id", "Venue", "name", "Venue", "icon", "🏛️", "desc", "Convention halls, lawns & resorts"),
                Map.of("id", "Makeup", "name", "Bridal Makeup", "icon", "💄", "desc", "Bridal makeover & beauty styling"),
                Map.of("id", "Videography", "name", "Videography", "icon", "🎥", "desc", "Drone coverage & full event films"),
                Map.of("id", "Mehendi", "name", "Mehendi", "icon", "✨", "desc", "Bridal mehendi & guest designs"),
                Map.of("id", "Event planning", "name", "Event Planning", "icon", "📋", "desc", "End-to-end full event coordination")
        );
        return ResponseEntity.ok(ApiResponse.ok("Categories retrieved", categories));
    }
}
