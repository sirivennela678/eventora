package com.eventmanagement.demo.controller;

import com.eventmanagement.demo.dto.ApiResponse;
import com.eventmanagement.demo.dto.RecentSearchDto;
import com.eventmanagement.demo.model.User;
import com.eventmanagement.demo.service.SearchService;
import com.eventmanagement.demo.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/search")
public class SearchController {

    private final SearchService searchService;
    private final UserService userService;

    public SearchController(SearchService searchService, UserService userService) {
        this.searchService = searchService;
        this.userService = userService;
    }

    @GetMapping("/suggestions")
    public ResponseEntity<ApiResponse<List<String>>> getSuggestions(
            @RequestParam(required = false, defaultValue = "HOME") String context,
            @RequestParam(required = false) String query) {

        List<String> suggestions = searchService.getSuggestions(context, query);
        return ResponseEntity.ok(ApiResponse.ok("Suggestions retrieved", suggestions));
    }

    @GetMapping("/recent")
    public ResponseEntity<ApiResponse<List<String>>> getRecentSearches(
            @RequestParam(required = false, defaultValue = "HOME") String context,
            HttpSession session) {

        User user = userService.getCurrentAuthenticatedUser(session);
        String sessionId = session != null ? session.getId() : null;

        List<String> recents = searchService.getRecentSearches(user, sessionId, context);
        return ResponseEntity.ok(ApiResponse.ok("Recent searches retrieved", recents));
    }

    @PostMapping("/recent")
    public ResponseEntity<ApiResponse<Void>> saveRecentSearch(
            @Valid @RequestBody RecentSearchDto dto,
            HttpSession session) {

        User user = userService.getCurrentAuthenticatedUser(session);
        String sessionId = session != null ? session.getId() : null;

        searchService.saveRecentSearch(user, sessionId, dto.getQuery(), dto.getPageContext());
        return ResponseEntity.ok(ApiResponse.ok("Recent search saved"));
    }

    @DeleteMapping("/recent")
    public ResponseEntity<ApiResponse<Void>> clearRecentSearches(HttpSession session) {
        User user = userService.getCurrentAuthenticatedUser(session);
        String sessionId = session != null ? session.getId() : null;

        searchService.clearRecentSearches(user, sessionId);
        return ResponseEntity.ok(ApiResponse.ok("Recent searches cleared"));
    }
}
