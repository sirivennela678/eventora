package com.eventmanagement.demo.controller;

import com.eventmanagement.demo.dto.ApiResponse;
import com.eventmanagement.demo.dto.PaymentRequestDto;
import com.eventmanagement.demo.model.Payment;
import com.eventmanagement.demo.model.User;
import com.eventmanagement.demo.service.PaymentService;
import com.eventmanagement.demo.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;
    private final UserService userService;

    public PaymentController(PaymentService paymentService, UserService userService) {
        this.paymentService = paymentService;
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Payment>> processPayment(
            @Valid @RequestBody PaymentRequestDto dto,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to process payment."));
        }

        Payment payment = paymentService.processPayment(dto, currentUser);
        String msg = "ADVANCE".equalsIgnoreCase(dto.getPaymentType())
                ? "50% Advance payment processed successfully! Transaction Ref: " + payment.getTransactionReference()
                : "Remaining 50% payment processed successfully! Event is fully paid and completed.";

        return ResponseEntity.ok(ApiResponse.ok(msg, payment));
    }

    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<ApiResponse<List<Payment>>> getBookingPayments(
            @PathVariable Long bookingId,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to view payment records."));
        }

        List<Payment> payments = paymentService.getPaymentsForBooking(bookingId, currentUser);
        return ResponseEntity.ok(ApiResponse.ok("Payment records retrieved", payments));
    }
}
