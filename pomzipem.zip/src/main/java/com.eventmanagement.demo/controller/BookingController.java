package com.eventmanagement.demo.controller;

import com.eventmanagement.demo.dto.ApiResponse;
import com.eventmanagement.demo.dto.BookingRequestDto;
import com.eventmanagement.demo.model.Booking;
import com.eventmanagement.demo.model.BookingStatus;
import com.eventmanagement.demo.model.Role;
import com.eventmanagement.demo.model.User;
import com.eventmanagement.demo.model.Vendor;
import com.eventmanagement.demo.service.BookingService;
import com.eventmanagement.demo.service.UserService;
import com.eventmanagement.demo.service.VendorService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;
    private final UserService userService;
    private final VendorService vendorService;

    public BookingController(BookingService bookingService,
                             UserService userService,
                             VendorService vendorService) {
        this.bookingService = bookingService;
        this.userService = userService;
        this.vendorService = vendorService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Booking>> createBooking(
            @Valid @RequestBody BookingRequestDto dto,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to create an event booking."));
        }

        Booking booking = bookingService.createBooking(dto, currentUser);
        return ResponseEntity.ok(ApiResponse.ok("Booking request submitted successfully! Status: PENDING", booking));
    }

    @GetMapping("/my-bookings")
    public ResponseEntity<ApiResponse<List<Booking>>> getCustomerBookings(
            @RequestParam(required = false) BookingStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) String query,
            @RequestParam(required = false, defaultValue = "newest") String sortBy,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to view your bookings."));
        }

        List<Booking> bookings = bookingService.getCustomerBookings(currentUser, status, startDate, endDate, query, sortBy);
        return ResponseEntity.ok(ApiResponse.ok("Bookings retrieved", bookings));
    }

    @GetMapping("/vendor-dashboard")
    public ResponseEntity<ApiResponse<List<Booking>>> getVendorBookings(
            @RequestParam(required = false) Long vendorId,
            @RequestParam(required = false) BookingStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) String query,
            @RequestParam(required = false, defaultValue = "newest") String sortBy,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to access vendor dashboard."));
        }

        Vendor vendor = null;
        if (vendorId != null) {
            vendor = vendorService.getVendorById(vendorId).orElse(null);
        } else {
            vendor = vendorService.getVendorByUser(currentUser).orElse(null);
            if (vendor == null && currentUser.getRole() == Role.ADMIN) {
                // Admin can view first vendor or all
                List<Vendor> all = vendorService.getAllVendors();
                if (!all.isEmpty()) vendor = all.get(0);
            }
        }

        if (vendor == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Vendor profile not found for this account."));
        }

        List<Booking> bookings = bookingService.getVendorBookings(vendor, status, startDate, endDate, query, sortBy);
        return ResponseEntity.ok(ApiResponse.ok("Vendor bookings retrieved", bookings));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Booking>> getBookingDetails(
            @PathVariable Long id,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to view booking details."));
        }

        Booking booking = bookingService.getBookingDetails(id, currentUser);
        return ResponseEntity.ok(ApiResponse.ok("Booking details retrieved", booking));
    }

    @PostMapping("/{id}/confirm")
    public ResponseEntity<ApiResponse<Booking>> confirmBooking(
            @PathVariable Long id,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to confirm booking."));
        }

        Booking booking = bookingService.confirmBookingByVendor(id, currentUser);
        return ResponseEntity.ok(ApiResponse.ok("Booking confirmed! Customer can now pay the 50% advance.", booking));
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<ApiResponse<Booking>> cancelBooking(
            @PathVariable Long id,
            @RequestBody(required = false) Map<String, String> body,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to cancel booking."));
        }

        String reason = body != null ? body.get("reason") : "No reason specified";
        Booking booking = bookingService.cancelBooking(id, currentUser, reason);
        return ResponseEntity.ok(ApiResponse.ok("Booking cancelled successfully.", booking));
    }

    @PostMapping({ "/{id}/complete", "/{id}/complete-service" })
    public ResponseEntity<ApiResponse<Booking>> markServiceCompleted(
            @PathVariable Long id,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to update service status."));
        }

        Booking booking = bookingService.markServiceCompletedByVendor(id, currentUser);
        return ResponseEntity.ok(ApiResponse.ok("Service completed at venue! Ready for customer to pay remaining 50%.", booking));
    }

    @PostMapping("/{id}/note")
    public ResponseEntity<ApiResponse<Booking>> addEventNote(
            @PathVariable Long id,
            @RequestBody Map<String, String> body,
            HttpSession session) {

        User currentUser = userService.getCurrentAuthenticatedUser(session);
        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Please login to post a message."));
        }

        String message = body != null ? body.get("message") : "";
        if (message == null || message.trim().isEmpty()) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Message cannot be empty."));
        }

        Booking booking = bookingService.addCommunicationNote(id, currentUser, message);
        return ResponseEntity.ok(ApiResponse.ok("Event communication note added.", booking));
    }
}
