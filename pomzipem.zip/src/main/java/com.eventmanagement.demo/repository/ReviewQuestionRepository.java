package com.eventmanagement.demo.repository;

import com.eventmanagement.demo.model.ReviewQuestion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReviewQuestionRepository extends JpaRepository<ReviewQuestion, Long> {

    List<ReviewQuestion> findByCategoryIgnoreCaseOrderByDisplayOrderAsc(String category);
}
