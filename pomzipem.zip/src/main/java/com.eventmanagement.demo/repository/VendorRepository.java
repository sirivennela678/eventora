package com.eventmanagement.demo.repository;

import com.eventmanagement.demo.model.Vendor;
import com.eventmanagement.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface VendorRepository extends JpaRepository<Vendor, Long> {

    List<Vendor> findByCategoryIgnoreCase(String category);

    Optional<Vendor> findByUser(User user);

    Optional<Vendor> findByUserId(Long userId);

    Optional<Vendor> findByEmailIgnoreCase(String email);

    @Query("SELECT v FROM Vendor v WHERE " +
           "(:category IS NULL OR LOWER(v.category) = LOWER(:category)) AND " +
           "(:location IS NULL OR LOWER(v.location) LIKE LOWER(CONCAT('%', :location, '%')) OR LOWER(v.serviceArea) LIKE LOWER(CONCAT('%', :location, '%'))) AND " +
           "(:query IS NULL OR LOWER(v.businessName) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(v.description) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(v.category) LIKE LOWER(CONCAT('%', :query, '%'))) AND " +
           "(:minPrice IS NULL OR v.startingPrice >= :minPrice) AND " +
           "(:maxPrice IS NULL OR v.startingPrice <= :maxPrice) AND " +
           "(:minRating IS NULL OR v.rating >= :minRating) AND " +
           "(:isAvailable IS NULL OR v.isAvailable = :isAvailable)")
    List<Vendor> searchVendors(
            @Param("query") String query,
            @Param("category") String category,
            @Param("location") String location,
            @Param("minPrice") Double minPrice,
            @Param("maxPrice") Double maxPrice,
            @Param("minRating") Double minRating,
            @Param("isAvailable") Boolean isAvailable);
}
