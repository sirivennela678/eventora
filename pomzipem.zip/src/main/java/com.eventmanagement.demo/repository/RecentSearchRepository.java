package com.eventmanagement.demo.repository;

import com.eventmanagement.demo.model.RecentSearch;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RecentSearchRepository extends JpaRepository<RecentSearch, Long> {

    List<RecentSearch> findTop8ByUserIdOrderByCreatedAtDesc(Long userId);

    List<RecentSearch> findTop8ByUserIdAndPageContextOrderByCreatedAtDesc(Long userId, String pageContext);

    List<RecentSearch> findTop8BySessionIdAndPageContextOrderByCreatedAtDesc(String sessionId, String pageContext);

    void deleteByUserId(Long userId);

    void deleteBySessionId(String sessionId);
}
