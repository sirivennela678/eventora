package com.eventmanagement.demo.repository;

import com.eventmanagement.demo.model.DesignPackage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DesignPackageRepository extends JpaRepository<DesignPackage, Long> {

    List<DesignPackage> findByVendorId(Long vendorId);

    List<DesignPackage> findByCategoryIgnoreCase(String category);

    List<DesignPackage> findByVendorIdAndThemeIgnoreCase(Long vendorId, String theme);

    @Query("SELECT dp FROM DesignPackage dp WHERE " +
           "(:vendorId IS NULL OR dp.vendor.id = :vendorId) AND " +
           "(:category IS NULL OR LOWER(dp.category) = LOWER(:category)) AND " +
           "(:theme IS NULL OR LOWER(dp.theme) LIKE LOWER(CONCAT('%', :theme, '%'))) AND " +
           "(:query IS NULL OR LOWER(dp.name) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(dp.description) LIKE LOWER(CONCAT('%', :query, '%'))) AND " +
           "(:minPrice IS NULL OR dp.price >= :minPrice) AND " +
           "(:maxPrice IS NULL OR dp.price <= :maxPrice) AND " +
           "(:isAvailable IS NULL OR dp.isAvailable = :isAvailable)")
    List<DesignPackage> searchPackages(
            @Param("vendorId") Long vendorId,
            @Param("query") String query,
            @Param("category") String category,
            @Param("theme") String theme,
            @Param("minPrice") Double minPrice,
            @Param("maxPrice") Double maxPrice,
            @Param("isAvailable") Boolean isAvailable);
}
