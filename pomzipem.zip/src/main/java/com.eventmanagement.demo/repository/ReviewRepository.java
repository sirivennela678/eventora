package com.eventmanagement.demo.repository;

import com.eventmanagement.demo.model.Review;
import com.eventmanagement.demo.model.ReviewType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByRevieweeVendorIdOrderByCreatedAtDesc(Long vendorId);

    List<Review> findByRevieweeCustomerIdOrderByCreatedAtDesc(Long customerId);

    List<Review> findByReviewerIdOrderByCreatedAtDesc(Long reviewerId);

    boolean existsByBookingIdAndReviewType(Long bookingId, ReviewType reviewType);

    Optional<Review> findByBookingIdAndReviewType(Long bookingId, ReviewType reviewType);
}
