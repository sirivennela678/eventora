package com.eventmanagement.demo.repository;

import com.eventmanagement.demo.model.Payment;
import com.eventmanagement.demo.model.PaymentType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    List<Payment> findByBookingIdOrderByCreatedAtDesc(Long bookingId);

    Optional<Payment> findByTransactionReference(String transactionReference);

    boolean existsByBookingIdAndPaymentTypeAndStatus(Long bookingId, PaymentType paymentType, String status);
}
