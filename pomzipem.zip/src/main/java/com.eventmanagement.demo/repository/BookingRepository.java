package com.eventmanagement.demo.repository;

import com.eventmanagement.demo.model.Booking;
import com.eventmanagement.demo.model.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByCustomerIdOrderByCreatedAtDesc(Long customerId);

    List<Booking> findByVendorIdOrderByCreatedAtDesc(Long vendorId);

    List<Booking> findByCustomerIdAndStatusOrderByCreatedAtDesc(Long customerId, BookingStatus status);

    List<Booking> findByVendorIdAndStatusOrderByCreatedAtDesc(Long vendorId, BookingStatus status);

    Optional<Booking> findByIdAndCustomerId(Long id, Long customerId);

    Optional<Booking> findByIdAndVendorId(Long id, Long vendorId);

    @Query("SELECT b FROM Booking b WHERE b.customer.id = :customerId AND " +
           "(:status IS NULL OR b.status = :status) AND " +
           "(:startDate IS NULL OR b.eventDate >= :startDate) AND " +
           "(:endDate IS NULL OR b.eventDate <= :endDate) AND " +
           "(:query IS NULL OR LOWER(b.vendor.businessName) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(b.eventType) LIKE LOWER(CONCAT('%', :query, '%'))) " +
           "ORDER BY b.createdAt DESC")
    List<Booking> searchCustomerBookings(
            @Param("customerId") Long customerId,
            @Param("status") BookingStatus status,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate,
            @Param("query") String query);

    @Query("SELECT b FROM Booking b WHERE b.vendor.id = :vendorId AND " +
           "(:status IS NULL OR b.status = :status) AND " +
           "(:startDate IS NULL OR b.eventDate >= :startDate) AND " +
           "(:endDate IS NULL OR b.eventDate <= :endDate) AND " +
           "(:query IS NULL OR LOWER(b.customer.name) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(b.eventType) LIKE LOWER(CONCAT('%', :query, '%'))) " +
           "ORDER BY b.createdAt DESC")
    List<Booking> searchVendorBookings(
            @Param("vendorId") Long vendorId,
            @Param("status") BookingStatus status,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate,
            @Param("query") String query);
}
