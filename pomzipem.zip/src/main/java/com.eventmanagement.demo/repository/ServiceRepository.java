package com.eventmanagement.demo.repository;

import com.eventmanagement.demo.model.ServiceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ServiceRepository extends JpaRepository<ServiceEntity, Long> {

    List<ServiceEntity> findByVendorId(Long vendorId);

    List<ServiceEntity> findByCategoryIgnoreCase(String category);

    @Query("SELECT s FROM ServiceEntity s WHERE " +
           "(:vendorId IS NULL OR s.vendor.id = :vendorId) AND " +
           "(:category IS NULL OR LOWER(s.category) = LOWER(:category)) AND " +
           "(:query IS NULL OR LOWER(s.name) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(s.description) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(s.vendor.businessName) LIKE LOWER(CONCAT('%', :query, '%'))) AND " +
           "(:minPrice IS NULL OR s.price >= :minPrice) AND " +
           "(:maxPrice IS NULL OR s.price <= :maxPrice)")
    List<ServiceEntity> searchServices(
            @Param("vendorId") Long vendorId,
            @Param("query") String query,
            @Param("category") String category,
            @Param("minPrice") Double minPrice,
            @Param("maxPrice") Double maxPrice);
}
