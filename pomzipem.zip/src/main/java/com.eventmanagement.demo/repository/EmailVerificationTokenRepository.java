package com.eventmanagement.demo.repository;

import com.eventmanagement.demo.model.EmailVerificationToken;
import com.eventmanagement.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface EmailVerificationTokenRepository extends JpaRepository<EmailVerificationToken, Long> {

    Optional<EmailVerificationToken> findByToken(String token);

    Optional<EmailVerificationToken> findByTokenAndUsedFalse(String token);

    Optional<EmailVerificationToken> findTopByUserAndUsedFalseOrderByCreatedAtDesc(User user);

    Optional<EmailVerificationToken> findTopByUser_EmailIgnoreCaseAndOtpAndUsedFalseOrderByCreatedAtDesc(String email, String otp);

    void deleteByUser(User user);
}
