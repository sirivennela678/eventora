package com.eventmanagement.demo;

import com.eventmanagement.demo.model.EmailVerificationToken;
import com.eventmanagement.demo.model.User;
import com.eventmanagement.demo.service.UserService;

import jakarta.servlet.http.HttpSession;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {

        try {
            if (request.name == null || request.name.trim().length() < 2) {
                return error("Please enter your full name.");
            }

            if (request.phone == null ||
                    !request.phone.trim().matches("^\\d{10}$")) {
                return error("Phone number must contain exactly 10 digits.");
            }

            if (request.email == null ||
                    !request.email.trim().matches(
                            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
                return error("Please enter a valid email address.");
            }

            if (request.password == null ||
                    request.password.length() < 6) {
                return error("Password must be at least 6 characters long.");
            }

            if (request.confirmPassword == null ||
                    !request.password.equals(request.confirmPassword)) {
                return error("Passwords do not match.");
            }

            com.eventmanagement.demo.dto.RegisterRequest serviceRequest = new com.eventmanagement.demo.dto.RegisterRequest();

            serviceRequest.setName(request.name.trim());
            serviceRequest.setPhone(request.phone.trim());
            serviceRequest.setEmail(request.email.trim());
            serviceRequest.setPassword(request.password);
            serviceRequest.setConfirmPassword(request.confirmPassword);
            serviceRequest.setRole(request.role);

            User user = userService.register(serviceRequest);

            Map<String, Object> data = new HashMap<>();
            data.put("id", user.getId());
            data.put("name", user.getName());
            data.put("email", user.getEmail());
            data.put("phone", user.getPhone());
            data.put("role", user.getRole().name());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put(
                    "message",
                    "Account created successfully. Please verify your email.");
            response.put("data", data);

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException | IllegalStateException e) {
            return error(e.getMessage());

        } catch (Exception e) {
            e.printStackTrace();
            return error("Unable to create your account. Please try again.");
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody LoginRequest request,
            HttpSession session) {

        try {
            if (request.email == null || request.email.trim().isEmpty()) {
                return error("Please enter your email address.");
            }

            if (request.password == null || request.password.isEmpty()) {
                return error("Please enter your password.");
            }

            User user = userService.login(
                    request.email,
                    request.password,
                    session);

            Map<String, Object> data = new HashMap<>();
            data.put("id", user.getId());
            data.put("name", user.getName());
            data.put("email", user.getEmail());
            data.put("phone", user.getPhone());
            data.put("role", user.getRole().name());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Login successful.");
            response.put("data", data);

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException | IllegalStateException e) {
            return error(e.getMessage());

        } catch (Exception e) {
            e.printStackTrace();
            return error("Unable to login. Please try again.");
        }
    }

    /*
     * RESEND OTP
     *
     * This endpoint uses the existing UserService verification system.
     * It does NOT change the OTP verification process.
     */
    @PostMapping("/resend-otp")
    public ResponseEntity<?> resendOtp(@RequestBody ResendOtpRequest request) {

        try {
            if (request.email == null ||
                    request.email.trim().isEmpty()) {
                return error("Please enter your email address.");
            }

            EmailVerificationToken token = userService.resendVerification(request.email.trim());

            Map<String, Object> response = new HashMap<>();

            response.put("success", true);
            response.put(
                    "message",
                    "A new verification code has been sent to your email.");

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException | IllegalStateException e) {
            return error(e.getMessage());

        } catch (Exception e) {
            e.printStackTrace();
            return error("Unable to resend verification code. Please try again.");
        }
    }

    @GetMapping("/me")
    public ResponseEntity<?> currentUser(HttpSession session) {

        User user = userService.getCurrentAuthenticatedUser(session);

        if (user == null) {
            return error("Not logged in.");
        }

        Map<String, Object> data = new HashMap<>();
        data.put("id", user.getId());
        data.put("name", user.getName());
        data.put("email", user.getEmail());
        data.put("phone", user.getPhone());
        data.put("role", user.getRole().name());

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("data", data);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpSession session) {

        userService.logout(session);

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Logged out successfully.");

        return ResponseEntity.ok(response);
    }

    private ResponseEntity<Map<String, Object>> error(String message) {

        Map<String, Object> response = new HashMap<>();

        response.put("success", false);
        response.put(
                "message",
                message != null ? message : "Something went wrong.");

        return ResponseEntity.badRequest().body(response);
    }

    public static class RegisterRequest {

        public String name;
        public String phone;
        public String email;
        public String password;
        public String confirmPassword;
        public String role;
    }

    public static class LoginRequest {

        public String email;
        public String password;
    }

    public static class ResendOtpRequest {

        public String email;
    }
}